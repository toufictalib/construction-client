package com.sab2i.dao;
import com.sab2i.vo.Achat;

public class AchatDao {

	public Achat Update2(Achat A1) {
		Achat A = new Achat();
		A.setID(A1.getID());
		A.setAcheteur(A1.getAcheteur());
		A.setQttm(A1.getQttm());
		A.setStatut(A1.getStatut());
		A.setdateAchat(A1.getdateAchat());
		return A;
	}

}
