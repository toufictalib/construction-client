package com.sab2i.controller.bean.request;

import com.kendoui.spring.models.DataSourceRequest;
import com.sab2i.common.GridInfo;

public class AbstractDataSourceRequest extends DataSourceRequest {

	
	public GridInfo toGridInfo()
	{
		GridInfo gridInfo = new GridInfo();
		gridInfo.setPage(getPage());
		gridInfo.setPageSize(getPageSize());
		gridInfo.setSkip(getSkip());
		gridInfo.setTake(getTake());
		return gridInfo;
	}
}
