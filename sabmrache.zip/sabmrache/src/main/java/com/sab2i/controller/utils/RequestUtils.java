package com.sab2i.controller.utils;

import javax.servlet.http.HttpServletRequest;

public class RequestUtils {

	public static boolean toBoolean(HttpServletRequest request, String key) {

		Object o = toType(request, key, Boolean.class);
		return o==null ? false : (Boolean)o;
	}

	@SuppressWarnings("unchecked")
	public static <T> T toType(HttpServletRequest request, String key, Class<T> classType) {
		Object o = request.getAttribute(key);
		try {
			return (T) o;
		} catch (ClassCastException e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
