package com.sab2i.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sab2i.controller.utils.HtmlUtils;
import com.sab2i.controller.utils.ProductUtils;
import com.sab2i.general.NotFoundItem;
import com.sab2i.product.IProduct;
import com.sab2i.product.Product;
import com.sab2i.vo.CategoryVO;

@Controller
public class CaracController {

	@Autowired
	private IProduct productImpl;

	
	@RequestMapping(value = "/carac", method = RequestMethod.GET)
	public ModelAndView showMessage(

	@RequestParam(value = "id", required = false, defaultValue = "2") Integer id) throws NotFoundItem {
		
		
		Product product = productImpl.getProductById(id);
		
		CategoryVO CC = new CategoryVO();
		CC.bindProduct(product);
		
		ModelAndView mv = new ModelAndView("carac");

		
		mv.addObject("id", id);
		mv.addObject("prix", CC.getprice());
		mv.addObject("nom", CC.getobjectname());
		mv.addObject("qd", CC.getqtt());
		mv.addObject("qm", CC.getqttmax());
		mv.addObject("sts", CC.getstatus());
		mv.addObject("vd", CC.getvendeur());
		mv.addObject("dt", CC.getdate());
		
		if (CC.getMainImageBytes() != null && CC.getMainImageBytes().length>0) {
			mv.addObject("img", encodeImage(CC.getMainImageBytes()));
		}
		
		mv.addObject("des", HtmlUtils.escape(CC.getdesc()));
		mv.addObject("cat", CC.getcat());
		mv.addObject("prix", CC.getprice());
		
		mv.addObject("imageUrls", CC.getImageUrls());
		
		List<String> otherImageImageBytesAsStringList = new ArrayList<>(CC.getOtherImageBytes().size());
		for (byte[] imageByte : CC.getOtherImageBytes()) {
			otherImageImageBytesAsStringList.add(encodeImage(imageByte));
		}
		mv.addObject("otherImageBytes", otherImageImageBytesAsStringList);
		mv.addObject("showReservationButton", ProductUtils.isReserveButtonShowing(product));

		return mv;
	}

	private String encodeImage(byte[] byteArray) {
		return "data:image/png;base64,"+new String(Base64.encodeBase64(byteArray));
	}
}