package com.sab2i.controller.bean.response;

import java.util.List;

public class ProductImages {

	private ProductImageResponse mainImage;
	private List<ProductImageResponse> otherImages;

	public ProductImageResponse getMainImage() {
		return mainImage;
	}

	public void setMainImage(ProductImageResponse mainImage) {
		this.mainImage = mainImage;
	}

	public List<ProductImageResponse> getOtherImages() {
		return otherImages;
	}

	public void setOtherImages(List<ProductImageResponse> otherImages) {
		this.otherImages = otherImages;
	}

}
