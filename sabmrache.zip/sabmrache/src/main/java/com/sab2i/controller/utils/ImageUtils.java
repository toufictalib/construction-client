package com.sab2i.controller.utils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.FileUtils;

public class ImageUtils {

	public static void deleteFromTemp(String path,String...imageNames) throws IOException
	{
		for(String imageName:imageNames)
		{
			FileUtils.forceDelete(new File(path, imageName));
		}
	}
	
	
}
