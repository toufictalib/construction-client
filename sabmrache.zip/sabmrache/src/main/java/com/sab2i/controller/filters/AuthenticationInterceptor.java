package com.sab2i.controller.filters;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.sab2i.controller.annotations.Admin;
import com.sab2i.general.Constants;
import com.sab2i.general.exceptions.NotLoggedException;

//com.sab2i.controller.filters.AuthenticationInterceptor
public class AuthenticationInterceptor extends HandlerInterceptorAdapter  {


	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		Object emailObject = request.getSession().getAttribute(Constants.SESSION_EMAIL);
		Object userIdObject = request.getSession().getAttribute(Constants.SESSION_USER_ID);
		Object isAdminObject =  request.getSession().getAttribute(Constants.SESSION_ADMIN);
		boolean isAdmin = Boolean.valueOf(isAdminObject==null ? "false" :isAdminObject.toString());
		
		//String path -
		if (handler instanceof HandlerMethod) {
		    HandlerMethod method = (HandlerMethod) handler;
		    
		    if (method.getMethod().isAnnotationPresent(Admin.class) && !isAdmin) {
		    	throw new NotLoggedException("You should be admin to access this url");
		    }
		}
		
		
		if (emailObject == null || userIdObject==null) {
			throw new NotLoggedException("");
		}
		return super.preHandle(request, response, handler);
	}
}
