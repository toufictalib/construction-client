package com.sab2i.controller.bean.response;

public class ProductImageResponse {

	private String name;
	private byte[] byteArray;

	public ProductImageResponse() {
		super();
	}

	public ProductImageResponse(String name, byte[] byteArray) {
		super();
		this.name = name;
		this.byteArray = byteArray;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getByteArray() {
		return byteArray;
	}

	public void setByteArray(byte[] byteArray) {
		this.byteArray = byteArray;
	}

}
