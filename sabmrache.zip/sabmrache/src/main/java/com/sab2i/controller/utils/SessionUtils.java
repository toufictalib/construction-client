package com.sab2i.controller.utils;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

public class SessionUtils {

	private final static Logger logger = Logger.getLogger(SessionUtils.class.getSimpleName());
	public static boolean toBoolean(HttpServletRequest request, String key) {

		Object o = toType(request, key, Boolean.class);
		return o==null ? false : (Boolean)o;
	}

	@SuppressWarnings("unchecked")
	public static <T> T toType(HttpServletRequest request, String key, Class<T> classType) {
		Object o = request.getSession().getAttribute(key);
		try {
			return (T) o;
		} catch (ClassCastException e) {
			logger.warning(e.getMessage());
		}
		
		return null;
	}

}
