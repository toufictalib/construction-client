package com.sab2i.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kendoui.spring.models.DataSourceResult;
import com.sab2i.category.Category;
import com.sab2i.category.ICategory;
import com.sab2i.common.ConfDetails;
import com.sab2i.common.GridInfo;
import com.sab2i.controller.annotations.Admin;
import com.sab2i.controller.bean.request.ProductRequest;
import com.sab2i.controller.utils.ProductUtils;
import com.sab2i.general.BaseController;
import com.sab2i.general.Constants;
import com.sab2i.general.Error;
import com.sab2i.general.ErrorResponse;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.Response;
import com.sab2i.general.SearchCriteria;
import com.sab2i.general.Success;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.general.exceptions.NotLoggedException;
import com.sab2i.order.IPurchase;
import com.sab2i.order.Order;
import com.sab2i.order.OrderSummary;
import com.sab2i.product.IProduct;
import com.sab2i.product.Product;
import com.sab2i.product.Reservation;
import com.sab2i.product.Status;
import com.sab2i.response.ReservationResponse;
import com.sab2i.utils.DateUtlis;
import com.sab2i.vo.CategoryVO;
import com.sab2i.vo.DashboardDetails;

@Controller
public class AdminController extends BaseController {

	@Autowired
	private ICategory categoryImpl;

	@Autowired
	private IProduct productImpl;

	@Autowired
	private IPurchase purchaseImpl;

	/**
	 * 
	 * @param name
	 * @return 
	 */
	@RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView("home");

		List<Category> categories = categoryImpl.getCategories();
		mv.addObject("categories", categories);
		mv.addObject("statuses", Status.values());
		return mv;
	}
	
	

	@RequestMapping("/productsOriginal")
	public ModelAndView original(@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		ModelAndView mv = new ModelAndView("adminpage");

		List<Category> categories = categoryImpl.getCategories();
		mv.addObject("categories", categories);
		return mv;
	}

	@RequestMapping(value="/productsByCategory", method = RequestMethod.POST)
	public @ResponseBody DataSourceResult  getProductsByCategory(@RequestBody ProductRequest productRequest,HttpServletRequest request) throws NotFoundItem, IOException {

		GridInfo gridInfo = productRequest.toGridInfo();
		List<Product> products = productImpl.getProductsByCategory(productRequest.getCatId(),gridInfo);

		// get current user Orders
		// List<Order> ordersByClient = purchaseImpl.getOrdersByClient(1);

		// merge data
		List<CategoryVO> categoryVOs = new ArrayList<>(products.size());

		for (Product product : products) {

			if (product.hasStock()) {
				CategoryVO categoryVO = new CategoryVO();
				categoryVO.bindProduct(product);
				categoryVO.setMainImageBytes(product.getImageBytes());
				categoryVOs.add(categoryVO);
			}

		}

		DataSourceResult dataSourceResult= new DataSourceResult();
		dataSourceResult.setData(categoryVOs);
		dataSourceResult.setTotal(productImpl.getProductTotalForAvailableStock(productRequest.getCatId()));
		return dataSourceResult;
	}



	@RequestMapping("/latestProducts")
	public @ResponseBody List<CategoryVO> getLatestProducts() throws NotFoundItem {

		List<Product> products = productImpl.getLatestAds(Constants.LATEST_PRODUCTS_COUNT);

		List<CategoryVO> categoryVOs = ProductUtils.toCategoryVo(products);

		return categoryVOs;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/searchProducts", method = RequestMethod.POST)
	public @ResponseBody DataSourceResult searchProducts(@RequestBody SearchCriteria searchCriteria) throws NotFoundItem {

		DataSourceResult dataSourceResult= productImpl.search(searchCriteria);

		List<CategoryVO> categoryVOs = ProductUtils.toCategoryVo((List<Product>) dataSourceResult.getData());

		dataSourceResult.setData(categoryVOs);
		return dataSourceResult;
	}

	@RequestMapping("/organizedProductsByCategory")
	public @ResponseBody DataSourceResult getProductsByCategorys(@RequestBody ViewCriteriaRequest viewCriteriaRequest) throws NotFoundItem, ParseException {

		List<Product> products = productImpl.trieListe(viewCriteriaRequest);

		

		// remove all products not including between selected dates

		List<CategoryVO> categoryVOs = ProductUtils.toCategoryVo(products);

		DataSourceResult dataSourceResult= new DataSourceResult();
		dataSourceResult.setData(categoryVOs);
		dataSourceResult.setTotal(productImpl.getProductTotalForAvailableStock(viewCriteriaRequest.getCatId()));
		return dataSourceResult;
	}




	/**
	 * 
	 * @param reservation
	 * @param request
	 * @return
	 * @throws NotFoundItem
	 * @throws NotLoggedException
	 */
	@RequestMapping("/reserveProduct")
	public @ResponseBody Response reserveProduct(@RequestBody Reservation reservation,HttpServletRequest request) throws NotFoundItem, NotLoggedException {

		//get user id from session
		reservation.setUserId(getCurrentUserId(request));
		
		//get selected product for update
		Product product = productImpl.getProductByIdForUpdate(reservation.getProductId());
		
		//get order by client id and product id if exists
		Order order = null;
		try {
			order = purchaseImpl.getOrderByClientIdAndProductId(reservation.getUserId(), reservation.getProductId());
			
		} catch (NotFoundItem e) {
			logger.info("Info:No Order has been purchased by user yet");
		}
				
		// Validate if reservation info 
		Response validateReservation = validateReservation(reservation, product,order);
		if (validateReservation instanceof ErrorResponse) {
			return validateReservation;
		}

		//In case no old order or order is sold we should create a new one
		if (order == null) {
			order = reservation.toOrder();

		} else {
			//In case of old order, incremant the quantity by the reservation quantity
			order.setQuantity(order.getQuantity() + reservation.getQuantity());
		}
		
		
		try {
			order.setStatus(Status.RESERVED);
			purchaseImpl.reserveProduct(order);
		} catch (Exception e) {
			return new ErrorResponse(resolveMessage(new Error("purchase.reservation.failure")));
		}

		//send email
		
		/*//to buyer
		Email.sendEmail(product.getClient().getEmail(), "Subject","Content");
		
		//to seller
		Email.sendEmail(getCurrentUserEmail(request), "Subject","Content");*/
		
		//get product after updating its values
		product = productImpl.getProductById(product.getId());
		
		
		//Reservation response
		ReservationResponse reservationResponse = new ReservationResponse();
		reservationResponse.setMessage(resolveMessage("purchase.reservation.success"));

		reservationResponse.setReserved(product.getReserved());
		reservationResponse.setSold(product.getSold());

		return new Success(reservationResponse);

	}

	/**
	 * Validate if user can reserve the selected product
	 * @param reservation
	 * @param product
	 * @param oldOrder
	 * @return
	 */
	private Response validateReservation(Reservation reservation, Product product,Order oldOrder) {

		// check quantity not exceeds available stock
		int availableStock = product.getAvailableStock();
		if (reservation.getQuantity() > availableStock) {
			return new ErrorResponse(resolveMessage(new Error("purchase.reservation.exceedStock"), reservation.getQuantity(), availableStock));
		}

		// in case the user has already reserved an item then try to reserve the same one the sum of two quantity
		// should not exceed the max quantity
		if (oldOrder!=null && ((oldOrder.getQuantity() + reservation.getQuantity()) > product.getMaxQuantityPerUser())) {
			return new ErrorResponse(resolveMessage(new Error("purchase.reservation.exceedMaxQuantity"), product.getMaxQuantityPerUser(),oldOrder.getQuantity()));
		}

		int sumOfSelectedProduct = purchaseImpl.getClientPurchaseQuantity(reservation.getProductId(), reservation.getUserId());
		// check if reserved quantity not exceeds value allowed per user
		if (sumOfSelectedProduct > product.getMaxQuantityPerUser()) {
			return new ErrorResponse(resolveMessage(new Error("purchase.reservation.exceedMaxQuantity"), product.getMaxQuantityPerUser(),sumOfSelectedProduct));
		}

		// check selling date
		if (product.getSellingDate().compareTo(new Date()) > 0) {
			return new ErrorResponse(resolveMessage(new Error("purchase.reservation.sellingDate"), DateUtlis.toLongDate(product.getSellingDate())));
		}

		return new Success();

	}

	@RequestMapping("/dashboard")
	@Admin
	/**
	 * 
	 * @return number of products, categories, orders and reserved products
	 */
	public @ResponseBody DashboardDetails getDashboardDetails()
	{
		DashboardDetails dashboardDetails = new DashboardDetails();
		dashboardDetails.setCategoryCount(categoryImpl.getCategoryCount());
		dashboardDetails.setProductCount(productImpl.getProductSummary().getAvailableProductCount());
		
		OrderSummary orderSummary = purchaseImpl.getOrderSummary();
		dashboardDetails.setReservedCount(orderSummary.getReserved());
		dashboardDetails.setOrderCount(orderSummary.getOrderCount());
		return dashboardDetails;
	}
	
	@RequestMapping("/confDetails")
	/**
	 * 
	 * @return configuration details
	 */
	public @ResponseBody List<ConfDetails> getConfDetails()
	{
		return configurationWrapper.getConfDetails();
	}
	
	@RequestMapping("/updateConfDetails")
	public @ResponseBody Response updateConfDetails(@RequestBody ConfDetails confDetails)
	{
		 configurationWrapper.update(confDetails);
		 return new Success();
	}
	
}