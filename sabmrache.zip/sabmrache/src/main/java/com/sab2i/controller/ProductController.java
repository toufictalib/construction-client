
package com.sab2i.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.sab2i.common.ICommon;
import com.sab2i.controller.bean.response.ProductImageResponse;
import com.sab2i.controller.bean.response.ProductImages;
import com.sab2i.general.BaseController;
import com.sab2i.general.Constants;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.Response;
import com.sab2i.general.Success;
import com.sab2i.product.IProduct;
import com.sab2i.product.Product;
import com.sab2i.product.ProductImage;
import com.sab2i.product.bean.ProductDeletion;

@Controller
@RequestMapping("/product")
public class ProductController extends BaseController {

	@Autowired
	private IProduct productImpl;
	
	@Autowired
	private ICommon commonImpl;

	@RequestMapping("/manageProduct")
	public String manageCategory() {
		return "product";
	}

	@RequestMapping(path="/productImage",method=RequestMethod.GET)
	public ModelAndView productImage(@RequestParam int productId) throws NotFoundItem {
		ModelAndView mv = new ModelAndView("productImage");

		Product product = productImpl.getProductById(productId);
		mv.addObject("multiFileBucket", new MultiFileBucket());
		mv.addObject("productId", productId);
		mv.addObject("productName", product.getName());
		return mv;
	}
	
	@RequestMapping("/all")
	public @ResponseBody List<Product> getProductsByCatId(@RequestParam int catId) throws NotFoundItem {
	     return  productImpl.getProductsByCategoryWithoutMainImage(catId);
	}

	@RequestMapping("/add")
	public @ResponseBody Product addProduct(@RequestBody Product product) throws NotFoundItem {

		product.setSellingTime(configurationWrapper.getSellingDate());
		
		Product newProduct =  productImpl.addProduct(product);
		
		return productImpl.getProductById(newProduct.getId());
	}

	@RequestMapping("/delete")
	public @ResponseBody Product getCategories(@RequestBody Product product) throws NotFoundItem {
		productImpl.deleteProduct(product.getId());
		return product;
	}

	@RequestMapping("/update")
	public @ResponseBody Product updateProduct(@RequestBody Product product) throws NotFoundItem {
		
		//Get old product and 
		Product oldProduct = productImpl.getProductById(product.getId());
		
		oldProduct.setName(product.getName());
		oldProduct.setDescription(product.getDescription());
		oldProduct.setPrice(product.getPrice());
		oldProduct.setClient(product.getClient());
		oldProduct.setNumpo(product.getNumpo());
		oldProduct.setCategory(product.getCategory());
		oldProduct.setMaxQuantityPerUser(product.getMaxQuantityPerUser());
		oldProduct.setInitialStock(product.getInitialStock());
		
		productImpl.updateProduct(oldProduct);
		return product;
	}

	@RequestMapping(value = "save", method = RequestMethod.POST)
	public @ResponseBody Response save(@RequestParam(name = "id") int productId, @RequestParam int mainImage, @RequestParam List<MultipartFile> files, HttpServletRequest request) throws Exception {

		boolean isMainImage = mainImage == Constants.IMAGE_MAIN;

		Product product = productImpl.getProductById(productId);
		if (isMainImage) {
			if (product.getMainImage() != null) {
				throw new Exception(resolveMessage("item.uploadImage.main.exist"));
			}
		} else {
			if (product.getOtherImages().size() + files.size() > Constants.MAX_ALLOWED_IMAGES) {
				throw new Exception(resolveMessage("item.uploadImage.other.exceeding", Constants.MAX_ALLOWED_IMAGES));
			}
		}


		// uploadFile(request, vo.getFile());
		for (MultipartFile file : files) {

			if (isMainImage) {
				ProductImage productMainImage = new ProductImage();
				productMainImage.setImageBytes(file.getBytes());
				productMainImage.setName(file.getOriginalFilename());
				productMainImage.setMainImage(product.getId());
				commonImpl.save(productMainImage);
				
			} else {
				ProductImage productImage = new ProductImage();
				productImage.setName(file.getOriginalFilename());
				productImage.setImageBytes(file.getBytes());
				productImage.setProduct(product.getId());
				commonImpl.save(productImage);
			}

		}


		return new Success(productId);

	}

	@RequestMapping(value = "remove", method = RequestMethod.POST)
	public @ResponseBody Response removeImages(@RequestBody ProductDeletion productDeletion, HttpServletRequest request) throws IOException, Exception {
		
		productImpl.deleteProductImage(productDeletion);
		
		return new Success(productDeletion.getProductId());

	}

	@RequestMapping("/loadImages")
	public @ResponseBody Response loadImages(@RequestParam int productId) throws NotFoundItem, IOException {
		Product product = productImpl.getProductById(productId);


		// response
		
		List<ProductImageResponse> otherImages = new ArrayList<>();
		for (ProductImage productImage : product.getOtherImages()) {
			otherImages.add(new ProductImageResponse(productImage.getName(), productImage.getImageBytes()));
		}
		
		
		ProductImages images = new ProductImages();

		if (product.hasMainImage()) {
			images.setMainImage(new ProductImageResponse(product.getImageName(), product.getImageBytes()));
		}
		images.setOtherImages(otherImages);

		return new Success(images);
	}
	
	/*@RequestMapping(value = "/getImage")//olxlb_2258870_1_261x203.jpg
	@ResponseBody
	public byte[] getImage(@RequestParam("name") String imageId,@RequestParam int productId,@RequestParam int mainImage,HttpServletRequest request) throws IOException  {
	String rpath=request.getRealPath("/");//olxlb_2258870_1_261x203.jpg
	rpath=	getProductPath()+ProductUtils.buildProductImageName(productId, mainImage==1, imageId); // whatever path you used for storing the file
	Path path = Paths.get(rpath);
	byte[] data = Files.readAllBytes(path); 
	return data;
	}
	
	*/

}
