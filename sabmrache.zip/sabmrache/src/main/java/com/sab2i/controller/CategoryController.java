package com.sab2i.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sab2i.category.Category;
import com.sab2i.category.ICategory;
import com.sab2i.general.BaseController;
import com.sab2i.general.NotFoundItem;

@Controller
@RequestMapping("/category")
public class CategoryController extends BaseController {

	@Autowired
	private ICategory categoryImpl;

	
	@RequestMapping("/manageCategories")
	public String manageCategory() {
		return "category";
	}

	@RequestMapping("/all")
	public @ResponseBody List<Category> getCategories() {
		return categoryImpl.getCategories();
	}
	
	@RequestMapping("/add")
	public  @ResponseBody Category addCategory(@RequestBody Category category) {
		 return categoryImpl.addCategory(category);
	}
	
	@RequestMapping("/delete")
	public @ResponseBody Category getCategories(@RequestBody Category category) throws NotFoundItem {
			categoryImpl.deleteCategory(category.getId());
			return category;
	}
	
	@RequestMapping("/update")
	public @ResponseBody Category updateCategory(@RequestBody Category category) throws NotFoundItem {
		categoryImpl.updateCategory(category);
		return category;
	}
}
