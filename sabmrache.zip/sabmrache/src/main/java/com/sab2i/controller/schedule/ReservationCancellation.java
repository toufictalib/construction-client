package com.sab2i.controller.schedule;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sab2i.order.IPurchase;

@Component("reservationCancellation")
public class ReservationCancellation {

	@Autowired
	private IPurchase purchaseImpl;
	private Logger logger = Logger.getLogger(getClass().getSimpleName());
	
	public ReservationCancellation() {
	}

	public void cancelReservation() {
		
		logger.info("Cancel Reservation");
		try
		{
		purchaseImpl.cancelReservation();
		}
		catch(Exception e)
		{
			logger.warning("Cancel Reservation Failed");
		}
	}
}
