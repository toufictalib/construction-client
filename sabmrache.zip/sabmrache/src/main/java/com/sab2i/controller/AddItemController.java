package com.sab2i.controller;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sab2i.category.ICategory;
import com.sab2i.general.BaseController;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.Response;
import com.sab2i.general.Success;
import com.sab2i.product.IProduct;
import com.sab2i.product.Product;
import com.sab2i.vo.CategoryVO;

@Controller
public class AddItemController extends BaseController {

	@Autowired
	private ICategory categoryImpl;

	@Autowired
	private IProduct productImpl;


	@RequestMapping(value = "/item/add", method = RequestMethod.GET)
	public ModelAndView student() {

		CategoryVO categoryVO = new CategoryVO();

		ModelAndView mv = new ModelAndView("item", "userForm", categoryVO);
		mv.addObject("categories", categoryImpl.getCategories());
		mv.addObject("title", resolveMessage("item.add"));
		mv.addObject("editMode", false);
		mv.addObject("action", "additem");
		return mv;
	}

	@RequestMapping(value = "/item/edit", method = RequestMethod.GET)
	public ModelAndView editItem(@RequestParam int id) throws NotFoundItem {

		Product product = productImpl.getProductById(id);
		CategoryVO categoryVO = new CategoryVO();
		categoryVO.bindProduct(product);

		ModelAndView mv = new ModelAndView("item", "userForm", categoryVO);
		mv.addObject("categories", categoryImpl.getCategories());
		mv.addObject("title", resolveMessage("item.edit", product.getName()));
		mv.addObject("editMode", true);
		mv.addObject("action", "editItem");
		return mv;
	}

	@RequestMapping("/item/delete")
	public @ResponseBody Response deleteProduct(@RequestParam(name = "id") int productId) throws NotFoundItem {
		productImpl.deleteProduct(productId);
		return new Success(resolveMessage("item.delete.success"));
	}

	public static String getServiceUrl(HttpServletRequest request) {
		String serverName = request.getServerName();
		int portNumber = request.getServerPort();
		String contextPath = request.getContextPath();

		String url = serverName + ":" + portNumber + contextPath;
		return url;
	}

	@RequestMapping(value = "/showProduct", method = RequestMethod.GET)
	public String showProduct(@RequestParam int id, ModelMap model) throws NotFoundItem {

		Product product = productImpl.getProductById(id);
		CategoryVO vo = new CategoryVO();
		vo.bindProduct(product);

		Logger.getLogger(getClass().getSimpleName()).log(Level.INFO, "Show Product");
		System.out.println(vo.getobjectname());
		model.addAttribute("objectname", vo.getobjectname());
		model.addAttribute("price", vo.getprice());
		model.addAttribute("desc", vo.getdesc());
		model.addAttribute("qtt", vo.getqtt());
		model.addAttribute("status", vo.getstatus());
		model.addAttribute("vendeur", vo.getvendeur());
		model.addAttribute("numpo", vo.getnumpo());
		model.addAttribute("qttmax", vo.getqttmax());
		model.addAttribute("date", vo.getdate());
		model.addAttribute("cat", vo.getcat());
		model.addAttribute("image", vo.getimage());
		return "result";
	}

}