package com.sab2i.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sab2i.general.BaseController;
import com.sab2i.general.ErrorResponse;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.Response;
import com.sab2i.general.SabException;
import com.sab2i.general.Success;
import com.sab2i.order.IPurchase;
import com.sab2i.order.OrderVo;
import com.sab2i.order.bean.ReservationInfo;
import com.sab2i.product.Status;

@Controller
@RequestMapping("/purchase")
public class PurchaseController extends BaseController {

	
	@Autowired
	private IPurchase purchaseImpl;
	
	@RequestMapping(value="/orders",method=RequestMethod.GET)
	public @ResponseBody List<OrderVo> getOrders()
	{
		List<OrderVo> orders  = purchaseImpl.getOrders(Status.RESERVED.ordinal());
		
		return orders;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public @ResponseBody Response deleteOrder(@RequestParam long id)
	{
		
		return new Success();
	}
	
	@RequestMapping(value="/cancel",method=RequestMethod.POST)
	public @ResponseBody Response cancelReservation(@RequestBody ReservationInfo reservationInfo) throws NotFoundItem
	{
			try {
				purchaseImpl.cancelReservation(reservationInfo);
			} catch (SabException e) {
				ErrorResponse errorResponse = new ErrorResponse(resolveError(e.getError()));
				return errorResponse;
			} 
		return new Success();
	}
	
	@RequestMapping(value="/sold",method=RequestMethod.POST)
	public @ResponseBody Response sold(@RequestBody ReservationInfo reservationInfo) throws NotFoundItem
	{
			
			try {
				purchaseImpl.confirmSold(reservationInfo);
			} catch (SabException e) {
				ErrorResponse errorResponse = new ErrorResponse(resolveError(e.getError()));
				return errorResponse;
			} 
		return new Success();
	}
}
