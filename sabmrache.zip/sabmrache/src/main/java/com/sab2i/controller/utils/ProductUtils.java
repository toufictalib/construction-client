package com.sab2i.controller.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sab2i.general.Constants;
import com.sab2i.product.Product;
import com.sab2i.product.Status;
import com.sab2i.vo.CategoryVO;

public class ProductUtils {

	public static List<CategoryVO> toCategoryVo(List<Product> products) {
		List<CategoryVO> categoryVOs = new ArrayList<>(products.size());
		for (Product product : products) {
			CategoryVO categoryVO = new CategoryVO();
			categoryVO.bindProduct(product);
			categoryVOs.add(categoryVO);
		}
		return categoryVOs;
	}

	public static String buildProductImageName(int productId,boolean isMainImage,String fileName)
	{
			String prefix = productId + "_";
			prefix += isMainImage ? Constants.PREFIX_IMAGE_MAIN : Constants.PERFIX_IMAGE_OTHER;
			prefix += fileName;
			return prefix;
	}
	
	/**
	 * 
	 * @param product
	 * @return
	 */
	public static boolean isReserveButtonShowing(Product product)
	{
		//checking if current date pass the selling date to allow the user 
		//reserve any product
		boolean show =  (new Date().getTime()- product.getSellingDate().getTime())>0;
		
		//if reserve button is showing , we can do  another check
		
		if(show)
		{
			//in case all product quantity has been sold, we should hide reserve button
			show = product.getStatus()!=Status.RESERVED;
		}
		
		return show;
		
	}
}
