package com.sab2i.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sab2i.category.ICategory;
import com.sab2i.client.Client;
import com.sab2i.controller.annotations.Admin;
import com.sab2i.controller.bean.request.UserInfo;
import com.sab2i.general.BaseController;
import com.sab2i.general.Constants;
import com.sab2i.general.ErrorResponse;
import com.sab2i.general.Response;
import com.sab2i.general.Success;
import com.sab2i.user.IUser;
import com.sab2i.user.LoginException;

@Controller
public class UserController extends BaseController {

	@Autowired
	private IUser userImpl;
	
	@Autowired
	private ICategory categoryImpl;

	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView("login");
		mv.addObject(Constants.REQUEST_USER_TITLE,"Utilisateur");
		return mv;
	}
	
	@RequestMapping("/signin")
	public @ResponseBody Response signIn(@RequestBody UserInfo userInfo,
			HttpServletRequest request,
			HttpServletResponse response) {
		
		String email = userInfo.getEmail();
		String password = userInfo.getPassword();
		
		Client client = null;
		try {
			client = userImpl.login(email, password);
		} catch (LoginException e) {
			ErrorResponse errorResponse = new ErrorResponse();
			errorResponse.setErrors(resolveMessages(e.getErrors()));
			return errorResponse;
		}
		
		
		//sessions
		request.getSession().setAttribute(Constants.SESSION_EMAIL, client.getEmail());
		request.getSession().setAttribute(Constants.SESSION_USER_ID, client.getId());
		request.getSession().setAttribute(Constants.SESSION_ADMIN, client.isAdmin());
		request.getSession().setAttribute(Constants.SESSION_USER_NAME,client.getName());
		
		return new Success("home");
	}

	@Admin
	@RequestMapping("/adminDashboard")
	public ModelAndView adminSignIn(ModelMap modelMap, HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("admin");
		request.getSession().setAttribute("isAdmin", true);
		
		mv.addObject("user", request.getSession().getAttribute(Constants.SESSION_USER_NAME));
		mv.addObject("categories", categoryImpl.getCategories());
		return mv;
	}
	
	
	
	@RequestMapping("/clients")
	public @ResponseBody List<Client> getClients()
	{
		return userImpl.getClients();
		
	}
	
	@RequestMapping("/logout")
	/**
	 * in case of logout, session must be free up 
	 * @param request
	 * @return
	 */
	public ModelAndView logout(HttpServletRequest request) {
		
		//boolean isAdmin = SessionUtils.toBoolean(request, Constants.SESSION_ADMIN);
		
		//free session
		request.getSession().removeAttribute(Constants.SESSION_EMAIL);
		request.getSession().removeAttribute(Constants.SESSION_USER_ID);
		request.getSession().removeAttribute(Constants.SESSION_ADMIN);
		request.getSession().removeAttribute(Constants.SESSION_USER_NAME);
		
		return new ModelAndView("redirect:" + ("login"));

	}

}
