package com.sab2i.controller.bean;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;

@Component
public class ImageHelper {

	public ImageHelper() {
	}

	public synchronized Image getImage(String path) throws IOException {
		File file = new File(path);
		return new ImageIcon(file.toURI().toURL()).getImage();
	}
	
	public synchronized byte[] getImageAsByteArray(String path) throws IOException {
		File file = new File(path);
		return FileUtils.readFileToByteArray(file);
	}
}
