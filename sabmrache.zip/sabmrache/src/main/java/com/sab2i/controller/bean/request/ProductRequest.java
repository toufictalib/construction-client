package com.sab2i.controller.bean.request;

public class ProductRequest extends AbstractDataSourceRequest {

	private int catId;

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}
	
	
}
