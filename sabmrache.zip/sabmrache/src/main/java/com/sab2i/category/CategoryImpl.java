package com.sab2i.category;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sab2i.general.NotFoundItem;

@Service
@Transactional
public class CategoryImpl implements ICategory {

	@Autowired
	private ICategoryDao categoryDao;
	
	@Override
	public List<Category> getCategories() {
		return categoryDao.getCategories();
	}

	@Override
	public Category getCategoryById(int id) throws NotFoundItem {
		return categoryDao.getCategoryById(id);
	}

	@Override
	public Category addCategory(Category category) {
		return categoryDao.addCategory(category);
		
	}

	@Override
	public void updateCategory(Category category) throws NotFoundItem {
		categoryDao.updateCategory(category);
	}

	@Override
	public void deleteCategory(int catId) throws NotFoundItem {
		categoryDao.deleteCategory(catId);
	}

	@Override
	public int getCategoryCount() {
		return categoryDao.getCategoryCount();
	}

}
