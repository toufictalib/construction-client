package com.sab2i.category;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.sab2i.general.AbstractDao;
import com.sab2i.general.NotFoundItem;

@Repository
public class CategoryDao extends AbstractDao implements ICategoryDao {

	/**
	 * use cache to persist category
	 */
	public Map<Integer, Category> categoryMap;

	public CategoryDao() {
		categoryMap = new HashMap<>();
	}

	@Override
	public List<Category> getCategories() {
		checkAndInit();
		return new ArrayList<>(categoryMap.values());
	}

	public void checkAndInit()
	{
		if(categoryMap.isEmpty())
		{
			refresh();
		}
	}
	/**
	 * empty category map then fill it from database
	 */
	public void refresh() {
		categoryMap.clear();
		for (Category category : list(Category.class)) {
			categoryMap.put(category.getId(), category);
		}
	}

	@Override
	public Category getCategoryById(int id) throws NotFoundItem {
		checkAndInit();
		if (categoryMap.get(id) != null) {
			return categoryMap.get(id);
		}
		throw new NotFoundItem("Category Not found for id " + id);
	}

	@Override
	public Category addCategory(Category category) {
		persist(category);
		refresh();
		return category;
	}

	@Override
	public void updateCategory(Category category) throws NotFoundItem {
		getSession().update(category);
		refresh();
	}

	@Override
	public void deleteCategory(int catId) throws NotFoundItem {
		Query createQuery = getSession().createQuery("delete Category where id ="+catId);
		createQuery.executeUpdate();
		categoryMap.remove(catId);
	}

	@Override
	public int getCategoryCount() {
		return categoryMap.size();
	}

}
