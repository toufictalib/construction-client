package com.sab2i.category;

import java.util.List;

import com.sab2i.general.NotFoundItem;

public interface ICategoryDao {

	List<Category> getCategories();

	Category getCategoryById(int id) throws NotFoundItem;

	Category addCategory(Category category) ;

	void updateCategory(Category category)throws NotFoundItem;

	void deleteCategory(int catId) throws NotFoundItem;

	int getCategoryCount();

}
