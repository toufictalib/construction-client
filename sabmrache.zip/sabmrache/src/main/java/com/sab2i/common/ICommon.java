package com.sab2i.common;

public interface ICommon {

	public Configuration geConfiguration();
	
	public Object updateObject(Object o);
	
	public Object save(Object o);
}
