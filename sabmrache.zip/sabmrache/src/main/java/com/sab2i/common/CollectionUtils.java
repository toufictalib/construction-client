package com.sab2i.common;

import java.util.List;

public class CollectionUtils {

	public static String toString(List<?> list, String sep) {
		StringBuilder builder = new StringBuilder();
		for (Object o : list) {
			builder.append(o.toString() + "" + sep);
		}

		if (builder.length() > 0) {
			return builder.substring(0, builder.length() - sep.length());
		}
		return builder.toString();
	}
}
