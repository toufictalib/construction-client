package com.sab2i.common;

import java.util.List;

public class Configuration {

	private List<ConfDetails> confDetails;
	
	

	public List<ConfDetails> getConfDetails() {
		return confDetails;
	}

	public void setConfDetails(List<ConfDetails> confDetails) {
		this.confDetails = confDetails;
	}

	
}
