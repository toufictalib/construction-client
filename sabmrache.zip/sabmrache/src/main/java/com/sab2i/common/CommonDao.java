package com.sab2i.common;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sab2i.general.AbstractDao;

@Repository
public class CommonDao extends AbstractDao implements ICommonDao {

	@Override
	public Configuration getConfiguration() {
		List<ConfDetails> list = list(ConfDetails.class);
		Configuration configuration = new Configuration();
		configuration.setConfDetails(list);
		return configuration;	
	}

	@Override
	public Object updateObject(Object o) {
		 update(o);
		 return o;
	}

	@Override
	public Object save(Object o) {
		persist(o);
		return o;
	}
	
	

}
