package com.sab2i.common;

public class GridInfo {

	private int pageSize = 0;
	private int page = 0;
	private int take;
    private int skip;

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTake() {
		return take;
	}

	public void setTake(int take) {
		this.take = take;
	}

	public int getSkip() {
		return skip;
	}

	public void setSkip(int skip) {
		this.skip = skip;
	}
	
	public int getStart()
	{
		return (page-1)*pageSize;
	}
	
	

}
