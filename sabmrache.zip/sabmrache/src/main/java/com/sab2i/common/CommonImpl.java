package com.sab2i.common;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CommonImpl  implements ICommon  {

	@Autowired
	private ICommonDao commonDao;
	
	@Override
	public Configuration geConfiguration() {
	return commonDao.getConfiguration();	
		
	}

	@Override
	public Object updateObject(Object o) {
		return commonDao.updateObject(o);
		
	}

	@Override
	public Object save(Object o) {
		return commonDao.save(o);
	}

}
