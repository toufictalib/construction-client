package com.sab2i.common;

public interface ICommonDao {
	public Configuration getConfiguration();

	public Object updateObject(Object o);

	public Object save(Object o);
}
