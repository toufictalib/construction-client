package com.sab2i.product;

public enum Status {
	IN_STOCK,RESERVED,SOLD;
	
	public String toString() {
		switch (this) {
		case IN_STOCK:
			return "EN STOCK";
		case RESERVED:
			return "RESERVE";
		case SOLD:
			return "VENDU";

		default:
			break;
		}
		
		throw new UnsupportedOperationException(this+" Status has not supported yet");
		
	};
	
	public static Status valueOf(int ordinal)
	{
		for(Status status:Status.values())
		{
			if(status.ordinal()==ordinal)
				return status;
		}
		
		throw new UnsupportedOperationException(ordinal+" Status has not supported yet");
	}
}
