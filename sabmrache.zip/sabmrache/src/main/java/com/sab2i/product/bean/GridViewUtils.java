package com.sab2i.product.bean;

import java.text.ParseException;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.util.StringUtils;

import com.sab2i.general.NotFoundItem;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.general.ViewWay;
import com.sab2i.utils.DateUtlis;

public class GridViewUtils {
	public static void getViewGrid(Criteria criteria, final ViewCriteriaRequest viewCriteria) throws NotFoundItem {

		final ViewWay viewWay = ViewWay.fromNumber(viewCriteria.getViewOrder());
		switch (viewWay) {
		case BETWEEN_DATE:
			if (viewWay == ViewWay.BETWEEN_DATE) {
				Date startDate = parseDate(viewCriteria.getStartDate());
				Date endDate = parseDate(viewCriteria.getEndDate());

				criteria.add(Restrictions.ge("creationDate", startDate));
				criteria.add(Restrictions.lt("creationDate", endDate));
			}
			break;
		case LATEST:
			criteria.addOrder( Order.desc("creationDate") );
			break;
		case OLDEST:
			criteria.addOrder( Order.asc("creationDate") );
			break;
		case ORDER_ALPHABETIQUE:
			criteria.addOrder( Order.asc("name") );
			break;
		case PRIX_CROISSANT:
			criteria.addOrder( Order.asc("price") );
			break;
		case PRIX_DECROISSANT: 
			criteria.addOrder( Order.desc("price") );
			break;

		default:
			break;
		}
	}

	private static Date parseDate(String date) {
		if (!StringUtils.isEmpty(date)) {
			try {
				return DateUtlis.parseDateInputValue(date);
			} catch (ParseException e) {
				e.printStackTrace();
				return new Date();
			}
		}
		return null;
	}
}
