package com.sab2i.product.bean;

/**
 * bean use to delete product image
 * 
 * @author talebt
 *
 */
public class ProductDeletion {

	private int productId;
	private int mainImage;
	private String fileName;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getMainImage() {
		return mainImage;
	}
	public void setMainImage(int mainImage) {
		this.mainImage = mainImage;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
