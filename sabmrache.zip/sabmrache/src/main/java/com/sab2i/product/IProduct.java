package com.sab2i.product;

import java.util.List;

import com.kendoui.spring.models.DataSourceResult;
import com.sab2i.common.GridInfo;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SearchCriteria;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.product.bean.ProductDeletion;

public interface IProduct {

	 List<Product> getLatestAds(int adsNumber) throws NotFoundItem;
	 
	 /**
	  * get Products by category according to paging needs
	  * @param catId
	  * @param gridInfo
	  * @return
	  * @throws NotFoundItem
	  */
	 List<Product> getProductsByCategory(int catId,GridInfo gridInfo) throws NotFoundItem;
	 
	 Product getProductById(int id) throws NotFoundItem;

	 /**
	  * return List of product after using search input at home page 
	  * @param searchCriteria
	  * @return
	  * @throws NotFoundItem
	  */
	 DataSourceResult search(SearchCriteria searchCriteria) throws NotFoundItem;
	
	 /**
	  * use this method to get product for update that prevent 
	  * other client getting product information before commint by locking user
	  * @param id
	  * @return
	  * @throws NotFoundItem
	  */
	Product getProductByIdForUpdate(int id) throws NotFoundItem;

	Product addProduct(Product product);
	
	void updateProduct(Product product);
	
	void deleteProduct(int produdctId) throws NotFoundItem;
	 
	/**
	 * return number of product not out of stock
	 * @return
	 */
	ProductSummary getProductSummary();
	
	/**
	 * return count of all products that not out of stock 
	 * @param catId
	 * @return
	 */
	Long getProductTotalForAvailableStock(int catId);

	/**
	 * return products according to "trier" panel found in home page
	 * @param viewCriteriaRequest
	 * @return
	 * @throws NotFoundItem
	 */
	List<Product> trieListe(ViewCriteriaRequest viewCriteriaRequest) throws NotFoundItem;

	/**
	 * return List of Product without attach main image
	 * for performance needs
	 * @param catId
	 * @return
	 * @throws NotFoundItem
	 */
	List<Product> getProductsByCategoryWithoutMainImage(int catId) throws NotFoundItem;

	/**
	 * delete product image
	 * @param productDeletion
	 */
	void deleteProductImage(ProductDeletion productDeletion);
}
