package com.sab2i.product;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyMain {

	public static void main(String[] args) {
		FileReader fileReader;
		try {
			fileReader = new FileReader("C:\\Users\\talebt\\Desktop\\readfrom.html");
			BufferedReader br = new BufferedReader(fileReader);
		    String line;
		    while ((line = br.readLine()) != null) {

		    	//image extract
		    	//Pattern p = Pattern.compile("(?m)(?s)<img\\s+(.*)src\\s*=\\s*\"([^\"]+)\"(.*)");
		    	
		    	//description
		    	//Pattern.compile("<strong>(.+?)</strong>");
		    	
		    	final Pattern p = Pattern.compile("<strong>(.+?)</strong>");
		    	Matcher m = p.matcher(line);
		    	if (m.find()) {
		    	  String src = m.group(1);
		    	  //System.out.println("\""+src+"\",");
		    	  System.out.println(src);
		    	}
		    }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
