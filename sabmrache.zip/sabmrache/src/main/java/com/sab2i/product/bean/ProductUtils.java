package com.sab2i.product.bean;

import java.util.ArrayList;
import java.util.List;

import com.sab2i.product.Product;


public class ProductUtils {

	public static List<Integer> toIds(List<Product> products) {
		List<Integer> productIds = new ArrayList<>(products.size());
		for (Product product : products) {
			productIds.add(product.getId());
		}

		return productIds;
	}
}
