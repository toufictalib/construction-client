package com.sab2i.product;

import java.util.List;

import com.kendoui.spring.models.DataSourceResult;
import com.sab2i.common.GridInfo;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SearchCriteria;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.product.bean.ProductDeletion;

public interface IProductDao {

	List<Product> getLatestAds(int adsNumber);

	List<Product> getProductsByCategory(int catId, GridInfo gridInfo);

	Product getProductById(int id) throws NotFoundItem;

	DataSourceResult search(SearchCriteria searchCriteria);

	Product getProductByIdForUpdate(int id) throws NotFoundItem;

	void updateProduct(Product product);

	Product addProduct(Product product);

	void deleteProduct(int produdctId) throws NotFoundItem;

	/**
	 * 
	 * @return ProductSummary
	 */
	ProductSummary getProductSummary();

	Long getProductTotalForAvailableStock(int catId);

	List<ProductImage> getMainProductImages(List<Integer> productIds);

	List<Product> trieListe(ViewCriteriaRequest viewCriteriaRequest) throws NotFoundItem;

	List<ProductImage> getOtherImages(int productId);

	List<Product> getAllProductsByCategory(int catId);

	void deleteProductImage(ProductDeletion productDeletion);
	
	void decrementProductReservedQuantity(int productId,int quantity);
}
