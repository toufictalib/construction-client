package com.sab2i.product;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.kendoui.spring.models.DataSourceResult;
import com.sab2i.common.GridInfo;
import com.sab2i.general.AbstractDao;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SearchCriteria;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.product.bean.GridViewUtils;
import com.sab2i.product.bean.ProductDeletion;
import com.sab2i.search.products.AddedDateCriteria;
import com.sab2i.search.products.AndCriteria;
import com.sab2i.search.products.CategoryCriteria;
import com.sab2i.search.products.SearchInputCriteria;
import com.sab2i.search.products.SearchQuery;
import com.sab2i.search.products.SellerCriteria;
import com.sab2i.search.products.StatusCriteria;
import com.sab2i.utils.DateUtlis;

@Repository
public class ProductDao extends AbstractDao implements IProductDao {

	private Class<Product> clazz = Product.class;

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getLatestAds(int adsNumber) {
		Criteria criteria = getSession().createCriteria(clazz);
		criteria.addOrder(Order.desc("timestamp"));
		criteria.setMaxResults(adsNumber);

		return criteria.list();
	}

	public List<Product> getProducts() {
		return list(clazz);
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * get products by category respecting page size and page
	 * return only products has stock that means initial stock>sold products
	 */
	public List<Product> getProductsByCategory(int catId,GridInfo gridInfo) {

		Criteria cr = getSession().createCriteria(LightProduct.class,"product");
		cr.add(Restrictions.eq("category.id", catId));
		cr.add(hasSold());
		cr.setFirstResult(gridInfo.getStart());
		cr.setMaxResults(gridInfo.getPageSize());
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<LightProduct> lightProducts =  cr.list();
		
		List<Product> products = new ArrayList<>(lightProducts.size());
		
		for(LightProduct lightProduct:lightProducts)
		{
			Product product = new Product();
			BeanUtils.copyProperties(lightProduct, product);
			products.add(product);
		}
		return products;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	/**
	 * get all products by category
	 */
	public List<Product> getAllProductsByCategory(int catId) {

		Criteria cr = getSession().createCriteria(LightProduct.class,"product");
		cr.add(Restrictions.eq("category.id", catId));
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<LightProduct> lightProducts =  cr.list();
		
		List<Product> products = new ArrayList<>(lightProducts.size());
		
		for(LightProduct lightProduct:lightProducts)
		{
			Product product = new Product();
			BeanUtils.copyProperties(lightProduct, product);
			products.add(product);
		}
		return products;
	}
	
	/**
	 * Product has sold in case initial stock is exceeding sold items
	 * @return 
	 */
	private Criterion hasSold()
	{
		return Restrictions.sqlRestriction("({alias}.initialStock - {alias}.sold)>0");
	}
	
	@Override
	public Long getProductTotalForAvailableStock(int catId)
	{
		Criteria criteriaCount = getSession().createCriteria(clazz);
		criteriaCount.setProjection(Projections.rowCount());
		criteriaCount.add(Restrictions.eq("category.id", catId));
		criteriaCount.add(hasSold());
		Long count = (Long) criteriaCount.uniqueResult();
		return count;
	}

	@Override
	public Product getProductById(int id) throws NotFoundItem {
		Product product = (Product) getSession().get(clazz, id);
		if (product != null) {
			return product;
		}
		throw new NotFoundItem("Product Not found for id " + id);
	}

	@Override
	public Product getProductByIdForUpdate(int id) throws NotFoundItem {
		String sql = "SELECT * FROM product WHERE id = :productId for update";
		SQLQuery query = getSession().createSQLQuery(sql);
		query.addEntity(clazz);
		query.setParameter("productId", id);
		Product product = (Product) query.uniqueResult();
		if (product != null) {
			return product;
		}
		throw new NotFoundItem("Product Not found for id " + id);
	}

	@Override
	public DataSourceResult search(SearchCriteria searchCriteria) {

		GridInfo gridInfo  = searchCriteria.toGridInfo();
		
		Criteria cr = getSession().createCriteria(Product.class,"product");
		cr.add(hasSold());
		cr.setFirstResult(gridInfo.getStart());
		cr.setMaxResults(gridInfo.getPageSize());
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		


		// in case no advanced search
		if (!searchCriteria.isAdvanced()) {
			if (!StringUtils.isEmpty(searchCriteria.getSearchInput())) {
				cr.add(Restrictions.ilike("name", "%"+searchCriteria.getSearchInput()+"%"));
			}
		} else {

			// advanced search
			advancedSearch(cr, searchCriteria);
		}

		//total
		Criteria criteriaCount = getSession().createCriteria(clazz);
		criteriaCount.setProjection(Projections.rowCount());
		criteriaCount.add(hasSold());
		if (!searchCriteria.isAdvanced()) {
			if (!StringUtils.isEmpty(searchCriteria.getSearchInput())) {
				criteriaCount.add(Restrictions.ilike("name", "%"+searchCriteria.getSearchInput()+"%"));
			}
		} else {

			// advanced search
			advancedSearch(criteriaCount, searchCriteria);
		}
		Long count = (Long) criteriaCount.uniqueResult();
		
		DataSourceResult dataSourceResult = new DataSourceResult();
		dataSourceResult.setData(cr.list());
		
		dataSourceResult.setTotal(count);
		
		return dataSourceResult;

	}

	@Override
	public void updateProduct(Product product) {

		getSession().update(product);

	}

	private void advancedSearch(Criteria criteria, SearchCriteria searchCriteria) {

		List<SearchQuery> queries = new ArrayList<>();
		SearchQuery mainQuery = new SearchInputCriteria(searchCriteria.getLibelle());
		
		try {
			if (!StringUtils.isEmpty(searchCriteria.getDate())) {
				queries.add(new AddedDateCriteria(DateUtlis.parseDateInputValue(searchCriteria.getDate())));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		if(!StringUtils.isEmpty(searchCriteria.getVendeur()))
		{
			queries.add(new SellerCriteria(searchCriteria.getVendeur()));
		}

		if (!StringUtils.isEmpty(searchCriteria.getCategorie())) {
			queries.add(new CategoryCriteria(Integer.parseInt(searchCriteria.getCategorie())));
		}

		if (!StringUtils.isEmpty(searchCriteria.getStatus())) {
			queries.add(new StatusCriteria(Status.valueOf(searchCriteria.getStatus()).ordinal()));
		}

		SearchQuery query = new AndCriteria(mainQuery, queries.toArray(new SearchQuery[queries.size()]));

		query.meetCriteria(criteria);

	}

	@Override
	public Product addProduct(Product product) {
		persist(product);
		return product;
	}

	@Override
	public void deleteProduct(int produdctId) throws NotFoundItem {
		Query createQuery = getSession().createQuery("delete Product where id ="+produdctId);
		createQuery.executeUpdate();
	}

	@Override
	public ProductSummary getProductSummary() {

		ProductSummary productSummary = new ProductSummary();
		int availableProduct = 0;
		for (Product product : getProducts()) {
			if (product.getSold() > 0)
				availableProduct++;
		}

		productSummary.setAvailableProductCount(availableProduct);
		return productSummary;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	/**
	 * get main images for list of products
	 */
	public List<ProductImage> getMainProductImages(List<Integer> productIds) {
		if (productIds == null || productIds.size() == 0) {
			return new ArrayList<>();
		}

		Criteria criteria = getSession().createCriteria(ProductImage.class);
		criteria.add(Restrictions.isNotNull("mainImage"));
		criteria.add(Restrictions.in("mainImage", productIds));

		return criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	/**
	 * get all images except the main image
	 */
	public List<ProductImage> getOtherImages(int productId) {

		Criteria criteria = getSession().createCriteria(ProductImage.class);
		criteria.add(Restrictions.isNotNull("product"));
		criteria.add(Restrictions.eq("product", productId));

		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> trieListe(ViewCriteriaRequest viewCriteriaRequest) throws NotFoundItem {
		GridInfo gridInfo  = viewCriteriaRequest.toGridInfo();
		int catId = viewCriteriaRequest.getCatId();
	
		Session session = getSession();
		Criteria cr = session.createCriteria(LightProduct.class,"product");
		logger.info("Get Product for CatID "+catId);
		cr.add(Restrictions.eq("category.id", catId));
		cr.add(hasSold());
		cr.setFirstResult(gridInfo.getStart());
		cr.setMaxResults(gridInfo.getPageSize());
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		GridViewUtils.getViewGrid(cr, viewCriteriaRequest);
		
		List<LightProduct> lightProducts =  cr.list();
		
		List<Product> products = new ArrayList<>(lightProducts.size());
		
		for(LightProduct lightProduct:lightProducts)
		{
			Product product = new Product();
			BeanUtils.copyProperties(lightProduct, product);
			products.add(product);
		}
		
		return products;
	}

	/**
	 * delete product images
	 */
	@Override
	public void deleteProductImage(ProductDeletion productDeletion) {
		
		//check if selected image is main image or not
		boolean isMainImage= productDeletion.getMainImage() == 1;
		int productId  = productDeletion.getProductId();
		String fileName = productDeletion.getFileName();
		
		//in case the selected image is main image we should delete where mainimage = productId
		//else we should delete where product = product id
		String hqlQuery = "";
		if (isMainImage) {
			hqlQuery = "delete ProductImage where mainImage =" + productId +" and name='"+fileName+"'";
		} else {
			hqlQuery = "delete ProductImage where product =" + productId +" and name='"+fileName+"'";
		}
		
		Query createQuery = getSession().createQuery(hqlQuery);
		createQuery.executeUpdate();
	}

	/**
	 * Add quantity to reserved field of selected product
	 */
	@Override
	public void decrementProductReservedQuantity(int productId, int quantity) {
		String hqlQuery = "update Product set reserved=reserved-"+quantity+" "
				+ "where id="+productId
				+" and reserved>="+quantity;
		Query query = getSession().createQuery(hqlQuery);
		query.executeUpdate();
	}
}
