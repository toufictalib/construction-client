package com.sab2i.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.sab2i.category.Category;
import com.sab2i.client.Client;
import com.sab2i.utils.DateUtlis;

@Entity
@Table(name="product")
public class LightProduct {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "price")
	private double price;


	 @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_creation",nullable=false)
	private Date creationDate = new Date();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client", nullable = false)
	private Client client;

	@Column(name = "numpo")
	private Integer numpo = 123;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category", nullable = false)
	private Category category;


	// on product creation only
	@Column(name = "maxQuantityPerUser")
	private int maxQuantityPerUser;

	@Column(name = "initialStock")
	private int initialStock;

	@Column(name = "sellingTime", updatable = false)
	private int sellingTime = 12;

	// update on reservation and sold
	@Column(name = "sold")
	private int sold = 0;

	@Column(name = "reserved")
	private int reserved = 0;

	public LightProduct() {
		super();
	}

	public LightProduct(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date date) {
		this.creationDate = date;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Integer getNumpo() {
		return numpo;
	}

	public void setNumpo(Integer numpo) {
		this.numpo = numpo;
	}

	
	

	public int getMaxQuantityPerUser() {
		return maxQuantityPerUser;
	}

	public void setMaxQuantityPerUser(int maxQuantity) {
		this.maxQuantityPerUser = maxQuantity;
	}

	public int getSold() {
		return sold;
	}

	public void setSold(int sold) {
		this.sold = sold;
	}

	public int getInitialStock() {
		return initialStock;
	}

	public void setInitialStock(int initialStock) {
		this.initialStock = initialStock;
	}

	public int getReserved() {
		return reserved;
	}

	public void setReserved(int reserved) {
		this.reserved = reserved;
	}

	public int getSellingTime() {
		return sellingTime;
	}

	public void setSellingTime(int sellingTime) {
		this.sellingTime = sellingTime;
	}

	public Date getSellingDate() {
		return DateUtlis.incrementHoursBy(getCreationDate(), getSellingTime());
	}

	public boolean hasStock() {
		return getAvailableStock() > 0;
	}

	public int getAvailableStock() {
		return initialStock - sold;
	}
	
	public Status getStatus() {
		if (hasStock()) {
			if (initialStock == reserved) {
				return Status.RESERVED;
			}
			return Status.IN_STOCK;
		}

		return Status.SOLD;
	}
	
	 @PrePersist
	    protected void onCreate() {
	    creationDate = new Date();
	    }

}
