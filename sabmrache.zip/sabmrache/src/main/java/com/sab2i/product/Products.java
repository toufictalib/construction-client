package com.sab2i.product;

import java.util.List;

public class Products {

	public Products() {
		super();
	}

	public Products(List<Product> products) {
		super();
		this.products = products;
	}

	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

}
