package com.sab2i.product;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Each Product has two types of images
 * 1-main image(1 only)
 * 2-other images(4 max)
 * if selected image is main, mainImage field must fill by product id and product field must be null
 * and vice versa
 * @author talebt
 *
 */
@Entity
@Table(name="product_image")
public class ProductImage {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	

	@Column(name="image_bytes")
	@JsonIgnore
	//@JsonSerialize(using= com.sab2i.general.utils.ByteArraySerializer.class)
	private byte[] imageBytes;
	
	@Column(name="main_image",nullable=true)
	protected Integer mainImage;
	
	@Column(name="product")
	protected Integer product;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getProduct() {
		return product;
	}

	public void setProduct(Integer product) {
		this.product = product;
	}

	public byte[] getImageBytes() {
		return imageBytes;
	}

	public void setImageBytes(byte[] imageBytes) {
		this.imageBytes = imageBytes;
	}

	public Integer getMainImage() {
		return mainImage;
	}

	public void setMainImage(Integer mainImage) {
		this.mainImage = mainImage;
	}
	
}
