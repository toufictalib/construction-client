package com.sab2i.product;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kendoui.spring.models.DataSourceResult;
import com.sab2i.category.ICategoryDao;
import com.sab2i.common.GridInfo;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SearchCriteria;
import com.sab2i.general.ViewCriteriaRequest;
import com.sab2i.product.bean.ProductDeletion;
import com.sab2i.product.bean.ProductUtils;
import com.sab2i.user.UserDao;

@Service
@Transactional
public class ProductImpl implements IProduct {

	@Autowired
	private IProductDao productDao;
	
	@Autowired
	private ICategoryDao categoryDao;
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public List<Product> getLatestAds(int adsNumber) throws NotFoundItem {
		List<Product> products = productDao.getLatestAds(adsNumber);
		attachCategory(products);
		return products;
	}

	@Override
	public List<Product> getProductsByCategory(int catId,GridInfo gridInfo) throws NotFoundItem {
		
		List<Product> products =  productDao.getProductsByCategory(catId,gridInfo);
		attachCategory(products);
		attachClient(products);
		attachMainImage(products);
		return products;
	}

	@Override
	public List<Product> getProductsByCategoryWithoutMainImage(int catId) throws NotFoundItem {
		
		List<Product> products =  productDao.getAllProductsByCategory(catId);
		attachCategory(products);
		attachClient(products);
		return products;
	}
	
	@Override
	public Product getProductById(int id) throws NotFoundItem {
		Product product =  productDao.getProductById(id);
		
		attachCategory(Arrays.asList(product));
		attachClient(Arrays.asList(product));
		attachMainImage(Arrays.asList(product));
		attachOtherImages(product);
		return product;
	}
	

	private void attachMainImage(List<Product> products) throws NotFoundItem
	{
		Map<Integer, ProductImage> imageByProductMap = new HashMap<>();
		
		for(ProductImage image:productDao.getMainProductImages(ProductUtils.toIds(products)))
			
		{
			imageByProductMap.put(image.getMainImage(), image);
		}
		
		for (Product product : products) {
			if (imageByProductMap.get(product.getId()) != null) {
				product.setMainImage(imageByProductMap.get(product.getId()));
			}
		}
	}
	
	private void attachOtherImages(Product product) {
		for (ProductImage productImage :  productDao.getOtherImages(product.getId())) {
				product.getOtherImages().add(productImage);
			}
	}
	
	private void attachClient(List<Product> asList) throws NotFoundItem {
		
		for(Product product:asList)
		{
			product.setClient(userDao.getUserById(product.getClient().getId()));
		}
		
	}

	private void attachCategory(List<Product> products) throws NotFoundItem
	{
		for(Product product:products)
		{
			product.setCategory(categoryDao.getCategoryById(product.getCategory().getId()));
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public DataSourceResult search(SearchCriteria searchCriteria) throws NotFoundItem {
		DataSourceResult dataSourceResult =		productDao.search(searchCriteria);
		List<Product> products = (List<Product>) dataSourceResult.getData();
		attachCategory(products);
		attachClient(products);
		return dataSourceResult;
	}

	@Override
	public Product getProductByIdForUpdate(int id) throws NotFoundItem {
		return productDao.getProductByIdForUpdate(id);
	}
	
	@Override
	public Product addProduct(Product product)
	{
		return productDao.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) {
		productDao.updateProduct(product);
		
	}

	@Override
	public void deleteProduct(int produdctId) throws NotFoundItem {
		productDao.deleteProduct(produdctId);
		
	}

	@Override
	public ProductSummary getProductSummary() {
		return productDao.getProductSummary();
	}

	@Override
	public Long getProductTotalForAvailableStock(int catId) {
		return productDao.getProductTotalForAvailableStock(catId);
	}

	@Override
	public List<Product> trieListe(ViewCriteriaRequest viewCriteriaRequest) throws NotFoundItem {
		List<Product> products =  productDao.trieListe(viewCriteriaRequest);
		attachCategory(products);
		attachClient(products);
		attachMainImage(products);
		return products;
	}

	@Override
	public void deleteProductImage(ProductDeletion productDeletion) {
		productDao.deleteProductImage(productDeletion);
		
	}

}
