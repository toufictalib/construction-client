package com.sab2i.product;

import java.util.Date;

import com.sab2i.client.Client;
import com.sab2i.order.Order;

/**
 * Info required to reserve product
 * we need user id, product id and quantity
 * userId is getting from server side
 * @author talebt
 *
 */
public class Reservation {

	private int userId;
	private int productId;
	private int quantity;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public Order toOrder()
	{
		Order order = new Order();
		order.setClient(new Client(userId));
		order.setProduct(new Product(productId));
		order.setPurchaseDate(new Date());
		order.setQuantity(quantity);
		
		return order;
	}
	

}
