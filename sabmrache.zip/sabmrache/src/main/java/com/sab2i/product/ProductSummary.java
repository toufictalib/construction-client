package com.sab2i.product;

public class ProductSummary {

	private int outOfStockProductCount;
	private int availableProductCount;
	

	public int getOutOfStockProductCount() {
		return outOfStockProductCount;
	}

	public void setOutOfStockProductCount(int outOfStockProductCount) {
		this.outOfStockProductCount = outOfStockProductCount;
	}

	public int getAvailableProductCount() {
		return availableProductCount;
	}

	public void setAvailableProductCount(int availableProductCount) {
		this.availableProductCount = availableProductCount;
	}


	
}
