package com.sab2i.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.sab2i.general.AbstractDao;
import com.sab2i.general.NotFoundItem;
import com.sab2i.product.Product;
import com.sab2i.product.Status;
import com.sab2i.utils.DateUtlis;

@Repository
public class PurchaseDao extends AbstractDao implements IPurchaseDao {

	private Class<Order> clazz = Order.class;
	@Override
	public void reserveProduct(Order order) {
		persist(order);
	}

	@Override
	public void updateOrder(Order order) {
		getSession().update(order);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Order> getOrdersByClient(int clientId) {
		Criteria criteria = getSession().createCriteria(clazz);
		criteria.add(Restrictions.eq("client.id", clientId));
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Order> getOrdersByProductId(int productId) {
		Criteria criteria = getSession().createCriteria(clazz);
		criteria.add(Restrictions.eq("product.id", productId));
		return criteria.list();
	}

	@Override
	//get order by client and product id and has reserved status
	public Order getOrderByClientIdAndProductId(int clientId, int productId) throws NotFoundItem {
		Criteria criteria = getSession().createCriteria(clazz);
		criteria.add(Restrictions.eq("client.id", clientId));
		criteria.add(Restrictions.eq("product.id",productId));
		criteria.add(Restrictions.eqOrIsNull("status", Status.RESERVED));
		Order order =  (Order) criteria.uniqueResult();
		if(order!=null)
		{
			return order;
		}

		throw new NotFoundItem("Current User has not any order yet");

	}

	@Override
	public int getReservedCountByProduct(int productId,int statusId) {

		int ctr = 0;
		List<Order> orders = getOrdersByProductId(productId);
		for (Order order : orders) {
			if (order.getStatus().ordinal() == statusId) {
				ctr += order.getQuantity();
			}
		}

		return ctr;
	}

	
	public List<Order> getOrders()
	{
		return list(clazz);
	}
	
	@Override
	public OrderSummary getOrderSummary() {
		
		int reserved = 0;
		int orderCount =0;
		for(Order order:getOrders())
		{
			if(order.getStatus()==Status.RESERVED)
			{
				reserved+=order.getQuantity();
				orderCount++;
			}
		}
		
		OrderSummary orderSummary = new OrderSummary();
		orderSummary.setReserved(reserved);
		orderSummary.setOrderCount(orderCount);
		return orderSummary;
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<OrderVo> getOrders(int status) {
		
		String sql ="    SELECT\r\n" + 
				"        pur.id as order_id,\r\n" + 
				"        pur.purchase_date as order_date,\r\n" + 
				"        pur.quantity as quantity,\r\n" + 
				"        pro.name as product_name,\r\n" + 
				"        cat.name as category_name,\r\n" + 
				"        cl.name as client_name,\r\n" + 
				"        seller.name as seller_name   \r\n" + 
				"    FROM\r\n" + 
				"        purchase pur          \r\n" + 
				"    LEFT JOIN\r\n" + 
				"        product pro                 \r\n" + 
				"            ON pur.product = pro.id          \r\n" + 
				"    LEFT JOIN\r\n" + 
				"        category cat                 \r\n" + 
				"            ON cat.id = pro.category          \r\n" + 
				"    LEFT JOIN\r\n" + 
				"        client cl                 \r\n" + 
				"            ON cl.id = pur.client          \r\n" + 
				"    LEFT JOIN\r\n" + 
				"        client seller                 \r\n" + 
				"            ON seller.id = pro.client  \r\n" + 
				"    where\r\n" + 
				"        pur.status=:status"
				+ " order by pur.purchase_date DESC";
		
		
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("status", status);
		query.addEntity(OrderVo.class);
		
		List results = query.list();
		return results;
	}

	@Override
	public void deleteOrder(long order) {
		Query createQuery = getSession().createQuery("delete Order where id ="+order);
		createQuery.executeUpdate();
		
	}

	@Override
	public void confirmSold(long order) {
		Query createQuery = getSession().createQuery("update Order set status ="+Status.SOLD +" where id ="+order);
		createQuery.executeUpdate();
	}

	@Override
	public Order getOrderById(long orderId) throws NotFoundItem {
		Order order =  (Order) getSession().get(clazz, orderId);
		if(order==null)
		{
			throw new NotFoundItem("Order with id "+orderId+" is not exist");
		}
		
		return order;
	}
	
	/**
	 * 
	 * @return the sum of selected product by client 
	 */
	@Override
	public Integer getClientPurchaseQuantity(int productId,int clientId)
	{
		String sql = "select sum(quantity) from purchase p\r\n" + 
				"where p.product = :productId and client = :clientId";
		
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("productId", productId);
		query.setParameter("clientId", clientId);
		
		Object object = query.uniqueResult();
		if(object!=null)
		{
			return ((BigDecimal)object).intValue();
		}
		return 0;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Order> getOrdersPassSelectedTime(int cancelReservationTime) {
		/**
		 *  current date - cancel reservation hours 
		 */
		Date date = DateUtlis.decrementHoursBy(new Date(), cancelReservationTime);

		//in case the order purchase date is  less than 
		//current date - cancel reservation hours 
		//that means order date pass the reservation time threshold
		Query query = getSession().createQuery("select id,quantity,product.id from Order where "
				+"status="+Status.RESERVED.ordinal()
				+ " and purchaseDate < '" + DateUtlis.formatAsMysqlDate(date)+"'");
		List<Object[]> rows = query.list();
	
		//convert query to collection of orders
		List<Order> orders = new ArrayList<>(rows.size());
		
		int ctr =0;
		for(Object[] object:rows)
		{
			ctr=0;
			Order order = new Order();
			order.setId((Long)object[ctr++]);
			order.setQuantity((Integer)object[ctr++]);
			order.setProduct(new Product((Integer)object[ctr++]));
			
			orders.add(order);
		}
		
		return orders;
	}

}
