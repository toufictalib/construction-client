package com.sab2i.order;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sab2i.general.ConfigurationWrapper;
import com.sab2i.general.Error;
import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SabException;
import com.sab2i.order.bean.ReservationInfo;
import com.sab2i.product.IProductDao;
import com.sab2i.product.Product;
import com.sab2i.product.Status;

@Service
@Transactional
public class PurchaseImpl implements IPurchase {

	@Autowired
	private IPurchaseDao purchaseDao;

	@Autowired
	private IProductDao productDao;

	@Autowired
	private ConfigurationWrapper configurationWrapper;

	
	@Override
	public void reserveProduct(Order order) throws Exception {
		
		//reserve product by creating an order
		
		if (order.getId() == null) {
			purchaseDao.reserveProduct(order);
		} else {
			purchaseDao.updateOrder(order);
		}
		
		//get Product for updating 
		//available stock and reserved items count
		Product product = productDao.getProductByIdForUpdate(order.getProductId());
		
		product.setReserved(purchaseDao.getReservedCountByProduct(order.getProductId(),Status.RESERVED.ordinal()));
		productDao.updateProduct(product);

	}

	@Override
	public List<Order> getOrdersByProductId(int productId) {
		return purchaseDao.getOrdersByProductId(productId);
	}

	@Override
	public List<Order> getOrdersByClient(int clientId) {
		return purchaseDao.getOrdersByClient(clientId);
	}

	@Override
	/**
	 * get order by client and product id and has reserved status
	 */
	public Order getOrderByClientIdAndProductId(int clientId, int productId) throws NotFoundItem {
		return purchaseDao.getOrderByClientIdAndProductId(clientId, productId);
	}

	@Override
	public OrderSummary getOrderSummary() {
		return purchaseDao.getOrderSummary();
	}

	@Override
	public List<OrderVo> getOrders(int status) {
		return purchaseDao.getOrders(status);
	}
	
	@Override
	public void deleteOrder(long orderId) throws Exception {

		cancelAndDeleteReservation(orderId, -1);

	}

	/**
	 * admin confirm sold for sepecifc product
	 */
	@Override
	@Transactional(rollbackOn=Exception.class)
	public void confirmSold(ReservationInfo reservationInfo) throws SabException, NotFoundItem {

		Order order = purchaseDao.getOrderById(reservationInfo.getOrderId());
		validateSelectedQuantity(order.getQuantity(), reservationInfo.getSelectedQuantity());

		Product product = productDao.getProductByIdForUpdate(order.getProductId());

		// in case the order has reserved status,
		// we should get the product reserved count and substract
		// the quantity of selected purchase order from product
		// and get the sold count and add the quantity of selected purchase order to sold count
		if(order.getStatus()==Status.RESERVED)
		{
			product.setReserved(product.getReserved() - reservationInfo.getSelectedQuantity());
			product.setSold(product.getSold() + reservationInfo.getSelectedQuantity());
			
			if(product.getAvailableStock()<0)
				throw new SabException(Error.create("order.orderQuantity.confirmSolde.exceed",
						(reservationInfo.getSelectedQuantity()-Math.abs(product.getAvailableStock()))
						));
			productDao.updateProduct(product);
		}

		// update order status to sold in case selectedQuantity to confirm sold is equal to order
		// quantity
		if (order.getQuantity() == reservationInfo.getSelectedQuantity()) {
			order.setStatus(Status.SOLD);
			purchaseDao.updateOrder(order);
		}
		// if user confirm per example 1 of 3 reserved item, we should create new
		// order has status sold and quantity equal to 1(selected quantity)
		else
		{
			Order newOrder = new Order();
			newOrder.setClient(order.getClient());
			newOrder.setProduct(product);
			newOrder.setPurchaseDate(new Date());
			newOrder.setQuantity(reservationInfo.getSelectedQuantity());
			newOrder.setStatus(Status.SOLD);
			purchaseDao.reserveProduct(newOrder);

			// decrement oldorder quantity bu selected quantity because
			// it has been sold
			order.setQuantity(order.getQuantity() - reservationInfo.getSelectedQuantity());
			purchaseDao.updateOrder(order);
		}

	}

	@Override
	public Integer getClientPurchaseQuantity(int productId, int clientId) {
		return purchaseDao.getClientPurchaseQuantity(productId, clientId);
	}

	@Override
	public void cancelReservation(ReservationInfo reservationInfo) throws SabException, NotFoundItem {
		cancelAndDeleteReservation(reservationInfo.getOrderId(), reservationInfo.getSelectedQuantity());

	}

	private void cancelAndDeleteReservation(long orderId, int selectedQuantity) throws SabException, NotFoundItem {

		Order order = purchaseDao.getOrderById(orderId);
		validateSelectedQuantity(order.getQuantity(), selectedQuantity);
		Product product = productDao.getProductByIdForUpdate(order.getProductId());

		// if selectedQuantity equal -1 that mean the method was called from
		// delete order so selectedQuantity is same as order quantity
		if(selectedQuantity==-1)
		{
			selectedQuantity = order.getQuantity();
		}

		// in case the order has reserved status,
		// we should get the product reserved count and substract
		// the quantity of deleted order from product
		if(order.getStatus()==Status.RESERVED)
		{
			product.setReserved(product.getReserved() - selectedQuantity);
			productDao.updateProduct(product);
		}

		// if selectedquantity == order quantity we should delete order or
		// update order quantity by substract it by selected quantity
		if (selectedQuantity == order.getQuantity()) {
			purchaseDao.deleteOrder(orderId);
		}
		else
		{
			order.setQuantity(order.getQuantity() - selectedQuantity);
			try {
				purchaseDao.updateOrder(order);
			} catch (Exception e) {
				throw new NotFoundItem(e.getMessage());
			}
		}
	}

	/**
	 * 1-selected quantity should not be exceeded order quantity 
	 * 2-selected quantity should be greater than 0
	 * 
	 * @param orderQuantity
	 * @param selectedQuantity
	 * @throws Exception
	 */
	private void validateSelectedQuantity(int orderQuantity, int selectedQuantity) throws SabException {
		if (selectedQuantity <= 0) {
			throw new SabException(Error.create("order.orderQuantity.selectedQuantity.greaterthanzero"));

		}
		if (selectedQuantity > orderQuantity) {
			throw new SabException(Error.create("order.orderQuantity.exceed", selectedQuantity, orderQuantity));
		}

	}

	/**
	 * we should check all orders with status "RESERVED" and check the time of purchase pass the reservation time already had been configured by admin If is passed, the order has been deleted and decrement the product reserved items by order quantity
	 */
	@Override
	public void cancelReservation() {

		// get all orders pass the reservation time threshold
		List<Order> ordersPassSelectedTime = purchaseDao.getOrdersPassSelectedTime(configurationWrapper.getSellingDate());

		for (Order order : ordersPassSelectedTime) {
			purchaseDao.deleteOrder(order.getId());
			productDao.decrementProductReservedQuantity(order.getProductId(), order.getQuantity());
		}

	}

}
