package com.sab2i.order;

import java.util.List;

import com.sab2i.general.NotFoundItem;

public interface IPurchaseDao {
	void reserveProduct(Order order);
	

	List<Order> getOrdersByClient(int clientId);

	List<Order> getOrdersByProductId(int productId);

	Order getOrderByClientIdAndProductId(int clientId, int productId) throws NotFoundItem;


	void updateOrder(Order order);


	int getReservedCountByProduct(int productId,int statusId);


	OrderSummary getOrderSummary();


	List<OrderVo> getOrders(int status);
	
	void deleteOrder(long order);
	
	void confirmSold(long order);
	
	Order getOrderById(long orderId) throws NotFoundItem;


	Integer getClientPurchaseQuantity(int productId, int clientId);


	List<Order> getOrdersPassSelectedTime(int cancelReservationTime);
}
