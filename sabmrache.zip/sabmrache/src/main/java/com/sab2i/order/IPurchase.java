package com.sab2i.order;

import java.util.List;

import com.sab2i.general.NotFoundItem;
import com.sab2i.general.SabException;
import com.sab2i.order.bean.ReservationInfo;

public interface IPurchase {

	void reserveProduct(Order order) throws Exception;
	
	List<Order> getOrdersByProductId(int productId);
	
	List<Order> getOrdersByClient(int clientId);
	
	Order getOrderByClientIdAndProductId(int clientId, int productId) throws NotFoundItem;
	
	OrderSummary getOrderSummary();
	
	List<OrderVo> getOrders(int status);

	void deleteOrder(long orderId) throws NotFoundItem, Exception;

	void confirmSold(ReservationInfo reservationInfo) throws SabException, NotFoundItem;
	
	void cancelReservation(ReservationInfo reservationInfo) throws SabException, NotFoundItem;
	
	
	Integer getClientPurchaseQuantity(int productId, int clientId);
	
	void cancelReservation();


}
