package com.sab2i.search.products;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class CategoryCriteria implements SearchQuery {

	private int category;

	public CategoryCriteria(int category) {
		super();
		this.category = category;
	}

	@Override
	public Criteria meetCriteria(Criteria criteria) {
		return criteria.add(Restrictions.eq("category.id", category));
	}


}
