package com.sab2i.search.products;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class SearchInputCriteria implements SearchQuery {

	private String text;

	public SearchInputCriteria(String text) {
		super();
		this.text = text;
	}


	@Override
	public Criteria meetCriteria(Criteria criteria) {
		return criteria.add(Restrictions.eq("name", text).ignoreCase());
	}

}
