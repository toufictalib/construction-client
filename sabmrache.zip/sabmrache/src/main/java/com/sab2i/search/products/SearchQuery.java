package com.sab2i.search.products;

import org.hibernate.Criteria;

public interface SearchQuery {
	public Criteria meetCriteria(Criteria criteria);
}
