package com.sab2i.search.products;

import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class AddedDateCriteria implements SearchQuery {

	private Date addedDate;
	
	
	public AddedDateCriteria(Date addedDate) {
		super();
		this.addedDate = addedDate;
	}


	@Override
	public Criteria meetCriteria(Criteria criteria) {
		return criteria.add(Restrictions.eq("creationDate", addedDate));
	}


	
}
