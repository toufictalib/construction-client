package com.sab2i.search.products;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class SellerCriteria implements SearchQuery {

	private String sellerName;
	
	
	public SellerCriteria(String sellerName) {
		super();
		this.sellerName = sellerName;
	}



	@Override
	public Criteria meetCriteria(Criteria criteria) {
		return criteria.createAlias("client", "client")
		.add(Restrictions.eq("client.name", sellerName).ignoreCase());
	}

}
