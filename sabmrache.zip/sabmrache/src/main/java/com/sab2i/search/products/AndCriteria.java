package com.sab2i.search.products;

import org.hibernate.Criteria;

public class AndCriteria implements SearchQuery {

	private SearchQuery criteria;
	private SearchQuery[] othersCriteria;

	public AndCriteria(SearchQuery criteria, SearchQuery... othersCriteria) {
		this.criteria = criteria;
		this.othersCriteria = othersCriteria;
	}

	@Override
	public Criteria meetCriteria(Criteria cr) {
		cr = criteria.meetCriteria(cr);
		for (SearchQuery othercriteria : othersCriteria) {
			cr = othercriteria.meetCriteria(cr);
		}
		return cr;
	}
}