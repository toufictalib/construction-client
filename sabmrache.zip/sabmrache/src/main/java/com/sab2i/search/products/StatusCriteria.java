package com.sab2i.search.products;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import com.sab2i.product.Status;

public class StatusCriteria implements SearchQuery {

	private int status;

	public StatusCriteria(int status) {
		super();
		this.status = status;
	}

	@Override
	public Criteria meetCriteria(Criteria criteria) {

		Status statusEnum = Status.valueOf(status);
		Criterion sqlRestriction = null;
		switch (statusEnum) {
		case SOLD:
			sqlRestriction = Restrictions.sqlRestriction("({alias}.initialStock - {alias}.sold)=0");
			break;
		case RESERVED:
			sqlRestriction = Restrictions.sqlRestriction("({alias}.initialStock = {alias}.reserved)");
			break;
			
		case IN_STOCK:
			sqlRestriction = Restrictions.sqlRestriction("({alias}.initialStock - {alias}.sold)>0");
			break;
		
		
		default:
			break;
		}

		if (sqlRestriction != null) {
			criteria.add(sqlRestriction);
		}
		return criteria;
	}

}
