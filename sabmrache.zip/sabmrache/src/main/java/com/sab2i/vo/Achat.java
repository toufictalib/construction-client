package com.sab2i.vo;

public class Achat {
	private Integer id;
	private String acheteur;
	private String statut;
	private Integer qttm;
	private String dateachat;

	public void setID(Integer id) {
		this.id = id;
	}

	public Integer getID() {
		return id;
	}

	public void setAcheteur(String acheteur) {
		if (acheteur != "")
			this.acheteur = acheteur;
		else
			this.acheteur = "Non Valide";
	}

	public String getAcheteur() {
		return acheteur;
	}

	public void setStatut(String statut) {
		if (statut == "RESERVE" || statut == "VENDU")
			this.statut = statut;
		else
			this.statut = "Non Valide";
	}

	public String getStatut() {
		return statut;
	}

	public void setQttm(int qttm) {
		if (qttm > 0)
			this.qttm = qttm;
		else
			this.qttm = 0;
	}

	public int getQttm() {
		return qttm;
	}

	public void setdateAchat(String dateachat) {
		this.dateachat = dateachat;
	}

	public String getdateAchat() {
		return dateachat;
	}

};
