package com.sab2i.vo;

public class DashboardDetails {

	private int productCount;
	private int categoryCount;
	private int reservedCount;
	private int orderCount;
	public int getProductCount() {
		return productCount;
	}
	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}
	public int getCategoryCount() {
		return categoryCount;
	}
	public void setCategoryCount(int categoryCount) {
		this.categoryCount = categoryCount;
	}
	public int getReservedCount() {
		return reservedCount;
	}
	public void setReservedCount(int reservedCount) {
		this.reservedCount = reservedCount;
	}
	public int getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}
	
	
}
