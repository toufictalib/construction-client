package com.sab2i.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sab2i.controller.utils.ProductUtils;
import com.sab2i.product.Product;
import com.sab2i.utils.DateUtlis;

//com.sab2i.vo.CategoryVO
public class CategoryVO {

	private Integer id;
	private double price;
	private String objectname;
	private String vendeur;
	private Integer numpo;
	private String acheteur;
	private int reserved;
	private int vendu;
	private String date;
	private String status;
	private String image;
	private byte[] mainImageBytes;
	private Integer qtt;
	private String cat;
	private int catId;
	private String desc;
	private Integer qttmax;
	private List<String> imageUrls;
	private List<byte[]> otherImageBytes;

	private int sellingTime;
	
	private boolean showReservationButton = false;

	public void setprice(double price) {
		if (price > 0)
			this.price = price;
		else
			this.price = -1;
	}

	public void setId(Integer i) {
		if (i > 0)
			id = i;
	}

	public Integer getId() {
		return id;
	}

	public void setobjectname(String objectname) {
		if (objectname != null)
			this.objectname = objectname;
	}

	public void setvendeur(String vendeur) {
		if (vendeur != null)
			this.vendeur = vendeur;
	}

	public void setnumpo(Integer numpo) {
		this.numpo = numpo;
	}

	public void setacheteur(String acheteur) {
		if (!acheteur.isEmpty())
			this.acheteur = acheteur;
		else
			this.acheteur = "xxxx";
	}

	public void setacheteur() {
		this.acheteur = "xxxx";
	}

	public int getReserved() {
		return reserved;
	}

	public void setReserved(int reserved) {
		this.reserved = reserved;
	}

	public int getVendu() {
		return vendu;
	}

	public void setVendu(int vendu) {
		this.vendu = vendu;
	}

	public void setdesc(String desc) {
		this.desc = desc;
	}

	public void setdate(String date) {
		if (date != null)
			this.date = date;
	}

	public void setstatus(String status) {
		if (status.equals("EN STOCK") || status.equals("RESERVE") || status.equals("VENDU"))
			this.status = status;
	}

	public void setimage(String image) {
		if (image != null && !image.isEmpty())
			this.image = image;
		else
			this.image = "http://www.epirusportal.gr/wp-content/uploads/default-no-image.png";
	}

	public void setimage() {
		this.image = "http://www.epirusportal.gr/wp-content/uploads/default-no-image.png";
	}

	public byte[] getMainImageBytes() {
		return mainImageBytes;
	}

	public void setMainImageBytes(byte[] mainImageBytes) {
		this.mainImageBytes = mainImageBytes;
	}

	public void setqtt(Integer qtt) {
		if (qtt > 0)
			this.qtt = qtt;
	}

	public void setqttmax(Integer qttmax) {
		if (qttmax > 0)
			this.qttmax = qttmax;
	}

	public void setcat(String cat) {
		this.cat = cat;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public double getprice() {
		return price;
	}

	public String getobjectname() {
		return objectname;
	}

	public String getvendeur() {
		return vendeur;
	}

	public Integer getnumpo() {
		return numpo;
	}

	public String getacheteur() {
		return acheteur;
	}

	public String getdate() {
		return date;
	}

	public String getstatus() {
		return status;
	}

	public String getdesc() {
		return desc;
	}

	public String getimage() {
		return image;
	}

	public Integer getqtt() {
		return qtt;
	}

	public Integer getqttmax() {
		return qttmax;
	}

	public String getcat() {
		return cat;
	}

	public List<String> getImageUrls() {
		return imageUrls;
	}

	public void setImageUrls(List<String> imageUrls) {
		this.imageUrls = imageUrls;
	}
	
	

	public List<byte[]> getOtherImageBytes() {
		return otherImageBytes;
	}

	public void setOtherImageBytes(List<byte[]> otherImageBytes) {
		this.otherImageBytes = otherImageBytes;
	}

	public int getSellingTime() {
		return sellingTime;
	}

	public void setSellingTime(int sellingTime) {
		this.sellingTime = sellingTime;
	}

	
	public boolean isShowReservationButton() {
		return showReservationButton;
	}

	public void setShowReservationButton(boolean showReservationButton) {
		this.showReservationButton = showReservationButton;
	}

	public static CategoryVO create() {
		CategoryVO CV = new CategoryVO();
		CV.setprice(600);
		CV.setobjectname("Iphone 6S");
		CV.setvendeur("Aude Javel");
		CV.setnumpo(722);
		CV.setacheteur();
		CV.setdate("12/02/2016");
		CV.setstatus("EN STOCK");
		CV.setimage("https://www.telstra.com.au/content/dam/tcom/personal/mobile-phones/product-catalogue/iphone-6/iphone6-grey-400-1.jpg");
		CV.setqtt(5);
		CV.setqttmax(3);

		List<String> imageUrls = new ArrayList<String>();
		imageUrls.add(CV.getimage());
		imageUrls.add("olxlb_2258819_1_261x203.jpg");
		imageUrls.add("olxlb_2258863_1_261x203.jpg");
		imageUrls.add("olxlb_2258882_1_261x203.jpg");
		CV.setImageUrls(imageUrls);
		return CV;
	}

	public void bindProduct(Product product) {
		setId(product.getId());
		setprice(product.getPrice());
		setobjectname(product.getName());
		// setdate(DateUtlis.toLongDate(product.getDate()));
		setcat(product.getCategory().getName());
		setCatId(product.getCategory().getId());
		setimage(product.getImageName());
		setMainImageBytes(product.getImageBytes());
		setvendeur(product.getClient().getName());
		setdesc(product.getDescription());

		List<String> imageUrls = new ArrayList<>();
		imageUrls.addAll(product.getOtherImageNames());
		setImageUrls(imageUrls);
		
		setOtherImageBytes(product.getOtherImageBytes());

		// to remove
		setnumpo(product.getNumpo());

		setqtt(product.getAvailableStock());
		setqttmax(product.getMaxQuantityPerUser());
		setstatus(product.getStatus().toString());
		setVendu(product.getSold());
		setReserved(product.getReserved());
		
		Date startSellingDate = product.getSellingDate();
		
		setdate(DateUtlis.toLongDate(startSellingDate));
		setShowReservationButton(ProductUtils.isReserveButtonShowing(product));
		
	}

};
