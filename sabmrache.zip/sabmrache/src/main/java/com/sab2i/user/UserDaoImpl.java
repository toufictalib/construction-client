package com.sab2i.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.sab2i.client.Client;
import com.sab2i.general.AbstractDao;
import com.sab2i.general.NotFoundItem;

@Repository
public class UserDaoImpl extends AbstractDao implements UserDao {

	private Class<Client> clazz = Client.class;

	private Map<Integer, Client> clientMap = new HashMap<>();

	@Override
	public Client login(String user, String password) throws LoginException {

		List<String> errors = new ArrayList<String>();
		Client client = null;
		try {
			client = getUserByEmail(user);
			if (!client.getEmail().equals(user)) {
				errors.add("user.login.wrongUser");
			}
			if (!client.getPassword().equals(password)) {
				errors.add("user.login.wrongPass");
			}
			
		} catch (NotFoundItem e) {
			errors.add("user.login.notFound");
		}
		
		if (errors.size() > 0)
			throw new LoginException(errors);
		
		return client;

	}

	@Override
	public Client getUserById(int id) throws NotFoundItem {
		Client client = (Client) getSession().get(clazz, id);
		if (client != null)
			return client;
		throw new NotFoundItem("User with id " + id + " does not exist");
	}

	@Override
	public Client getUserByEmail(String email) throws NotFoundItem {
		Criteria cr = getSession().createCriteria(clazz);
		cr.add(Restrictions.eq("email", email));
		Client client = (Client) cr.uniqueResult();
		if (client != null) {
			return client;
		}

		throw new NotFoundItem("User with email " + email + " is not exist");
	}

	@Override
	public List<Client> getClients() {
		if (clientMap.isEmpty()) {
			refresh();
		}
		return new ArrayList<>(clientMap.values());
	}

	public void refresh() {
		clientMap.clear();
		for (Client client : list(Client.class)) {
			clientMap.put(client.getId(), client);
		}
	}

}
