package com.sab2i.user;

import java.util.List;

import com.sab2i.client.Client;
import com.sab2i.general.NotFoundItem;

public interface UserDao {

	public Client login(String user, String password) throws LoginException;
	
	public Client getUserById(int id) throws NotFoundItem;
	
	public Client getUserByEmail(String email) throws NotFoundItem;
	
	public List<Client> getClients();
}
