package com.sab2i.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sab2i.client.Client;
import com.sab2i.general.NotFoundItem;

@Service
@Transactional
public class UserImpl implements IUser {

	@Autowired
	private UserDao userDao;
	
	@Override
	public Client login(String user, String password) throws LoginException {
		
		return userDao.login(user, password);
	}
	
	@Override
	public Client getUserById(int id) throws NotFoundItem {
		return userDao.getUserById(id);
	}

	@Override
	public Client getUserByEmail(String email) throws NotFoundItem {
		return userDao.getUserByEmail(email);
	}

	@Override
	public List<Client> getClients() {
		return userDao.getClients();
	}

}
