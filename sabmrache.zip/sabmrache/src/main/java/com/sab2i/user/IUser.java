package com.sab2i.user;

import java.util.List;

import com.sab2i.client.Client;
import com.sab2i.general.NotFoundItem;

public interface IUser {
	
	public Client login(String user, String password) throws LoginException;

	Client getUserById(int id) throws NotFoundItem;

	Client getUserByEmail(String email) throws NotFoundItem;
	
	List<Client> getClients();
	
	
}
