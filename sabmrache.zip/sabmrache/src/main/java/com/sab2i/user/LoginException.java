package com.sab2i.user;

import java.util.List;

import com.sab2i.general.SabException;

public class LoginException extends SabException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 980144600637083146L;

	public LoginException() {
		super();
	}


	public LoginException(String message, Throwable cause) {
		super(message, cause);
	}

	public LoginException(String message) {
		super(message);
	}

	public LoginException(Throwable cause) {
		super(cause);
	}


	public LoginException(List<String> errors) {
		super(errors);
	}

}
