package com.sab2i.response;

/**
 * message of success and
 * sold product sold quantity and
 * reserved product reserved quantity 
 * @author talebt
 *
 */
public class ReservationResponse {

	private String message;
	private int sold;
	private int reserved;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getSold() {
		return sold;
	}

	public void setSold(int sold) {
		this.sold = sold;
	}

	public int getReserved() {
		return reserved;
	}

	public void setReserved(int reserved) {
		this.reserved = reserved;
	}

}
