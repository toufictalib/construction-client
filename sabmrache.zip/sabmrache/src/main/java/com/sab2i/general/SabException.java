package com.sab2i.general;

import java.util.ArrayList;
import java.util.List;

public class SabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1263782231865832737L;
	private List<Error> errors = new ArrayList<Error>();

	public SabException() {
		super();
	}

	public SabException(String message, Throwable cause) {
		super(message, cause);
	}

	public SabException(Error error)
	{
		this.errors.add(error);
	}
	public SabException(String message) {
		super(message);
	}

	public SabException(Throwable cause) {
		super(cause);
	}

	public SabException(List<String> errors) {
		List<Error> messages = new ArrayList<Error>(errors.size());
		for (String error : errors) {
			messages.add(new Error(error));
		}
		this.errors.addAll(messages);
	}

	public void addError(Error error)

	{
		errors.add(error);
	}

	public List<Error> getErrors() {
		return errors;
	}

	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}
	
	/**
	 * in case we have only one error we use this method and
	 * return empty error in case no erros
	 * @return
	 */
	public Error getError()
	{
		if(errors.size()>0)
		{
			return errors.get(0);
		}
		return new Error();
	}

}
