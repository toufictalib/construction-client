package com.sab2i.general;

public class ConfigurationConstants {

	private ConfigurationConstants() {

	}

	public static final int SELLING_DEFAULT_VALUE = 12;
	public static final int RESERVATION_DEFAULT_VALUE = 24;
	public static final String SELLING_DATE = "SELLING_TIME";
	public static final String SEND_EMAIL = "SEND_EMAIL";
	public static final String RESERVATION_TIME = "RESERVATION_TIME";
	public static final String SMTP = "smtp";
	
}
