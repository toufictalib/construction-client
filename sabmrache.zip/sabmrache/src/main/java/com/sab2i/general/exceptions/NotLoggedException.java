package com.sab2i.general.exceptions;

public class NotLoggedException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2749303991796289076L;

	public NotLoggedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NotLoggedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NotLoggedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NotLoggedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NotLoggedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
