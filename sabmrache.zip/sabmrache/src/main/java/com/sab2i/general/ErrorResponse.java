package com.sab2i.general;

import java.util.Arrays;
import java.util.List;

public class ErrorResponse extends Response {
	private List<Error> errors;

	public ErrorResponse(List<Error> errors) {
		this();
		this.errors = errors;
	}

	public ErrorResponse(Error error) {
		this(Arrays.asList(error));
	}

	public ErrorResponse() {
		this.success = false;
	}

	public List<Error> getErrors() {
		return errors;
	}

	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}

}
