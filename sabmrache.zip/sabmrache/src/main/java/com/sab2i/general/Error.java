package com.sab2i.general;

public class Error {

	private String code;
	private Object[]params;
	private String message;
	
	public Error() {
		super();
	}

	public Error(String code) {
		super();
		this.code = code;
	}
	
	public static Error create(String code,Object...params)
	{
		Error error = new Error(code);
		error.setParams(params);
		return error;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object[] getParams() {
		return params;
	}

	public void setParams(Object[] params) {
		this.params = params;
	}
	
	
	
	

}
