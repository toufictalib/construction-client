package com.sab2i.general;

import com.sab2i.controller.bean.request.AbstractDataSourceRequest;

public class SearchCriteria extends AbstractDataSourceRequest {

	private boolean advanced;
	private String searchInput;
	private String libelle;
	private String date;
	private String vendeur;
	private String categorie;
	private String status;

	public boolean isAdvanced() {
		return advanced;
	}

	public void setAdvanced(boolean advanced) {
		this.advanced = advanced;
	}

	public String getSearchInput() {
		return searchInput;
	}

	public void setSearchInput(String searchInput) {
		this.searchInput = searchInput;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getVendeur() {
		return vendeur;
	}

	public void setVendeur(String vendeur) {
		this.vendeur = vendeur;
	}

	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isSearchInputEmpty() {
		return searchInput == null || searchInput.isEmpty();
	}
}
