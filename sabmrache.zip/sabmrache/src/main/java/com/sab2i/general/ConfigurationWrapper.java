package com.sab2i.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.NumberUtils;

import com.sab2i.common.ConfDetails;
import com.sab2i.common.ICommon;

@Component
public class ConfigurationWrapper {

	@Autowired
	private ICommon commonImpl;
	
	private final static Logger logger = Logger.getLogger(ConfigurationWrapper.class.getSimpleName());

	private Map<String, ConfDetails> map = new HashMap<>();

	public ConfigurationWrapper() {

	}

	private void refresh() {
		map.clear();
		for (ConfDetails confDetails : commonImpl.geConfiguration().getConfDetails()) {
			map.put(confDetails.getKey(), confDetails);
		}
	}

	private void checkAndInit() {
		if (map.isEmpty()) {
			refresh();
		}

	}

	public Object getValue(String key) {
		if (getConfDetails(key) != null) {
			return getConfDetails(key).getValue();
		}
		logger.warning("Cannot find a configuration details for "+key);
		return null;
	}

	public int getSellingDate() {
		Object value = getValue(ConfigurationConstants.SELLING_DATE);

		if (value != null) {
			try {
				return NumberUtils.parseNumber(value.toString(), Integer.class);
			} catch (NumberFormatException e) {
				Logger.getLogger(getClass().getSimpleName()).info("Selling Time "+e.getMessage());
			}

		}
		return ConfigurationConstants.SELLING_DEFAULT_VALUE;
	}
	
	public int getReservationTime() {
		Object value = getValue(ConfigurationConstants.RESERVATION_TIME);

		if (value != null) {
			try {
				return NumberUtils.parseNumber(value.toString(), Integer.class);
			} catch (NumberFormatException e) {
				Logger.getLogger(getClass().getSimpleName()).info("Reservation Time "+e.getMessage());
			}

		}
		return ConfigurationConstants.RESERVATION_DEFAULT_VALUE;
	}

	public List<ConfDetails> getConfDetails() {
		checkAndInit();
		return new ArrayList<>(map.values());
	}

	public ConfDetails getConfDetails(String key) {
		checkAndInit();
		return map.get(key);
	}

	public void update(ConfDetails confDetails) {
		ConfDetails olConfDetails = getConfDetails(confDetails.getKey());
		if (olConfDetails != null) {
			olConfDetails.setValue(confDetails.getValue());
			olConfDetails.setKeyLabel(confDetails.getKeyLabel());
			commonImpl.updateObject(olConfDetails);
			refresh();

		}

	}

}
