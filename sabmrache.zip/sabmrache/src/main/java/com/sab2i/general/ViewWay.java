package com.sab2i.general;

public enum ViewWay {

	BETWEEN_DATE,
	PRIX_CROISSANT,
	PRIX_DECROISSANT,
	ORDER_ALPHABETIQUE,
	LATEST,
	OLDEST;

	
	public static ViewWay fromNumber(int num) throws NotFoundItem {
		
		//we take same order on frontend and the value starts from 1 and enum ordinal starts from 0 
		//so we decrement num by one.
		//we should 
		//take care about any changes on fronted 
		num = num-1;
		for (ViewWay viewWay : ViewWay.values()) {
			if (num == viewWay.ordinal())
				return viewWay;
		}

		throw new NotFoundItem("No ViewWay has found for " + num);
	}
}
