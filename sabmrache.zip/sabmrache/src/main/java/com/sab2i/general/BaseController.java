package com.sab2i.general;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.sab2i.controller.bean.ImageHelper;
import com.sab2i.general.exceptions.NotLoggedException;

public class BaseController extends AbstractController {

	private Locale locale = Locale.FRANCE;

	protected Logger logger = Logger.getLogger(BaseController.class.getSimpleName());
	@Autowired
	private ResourceBundleMessageSource messageSource;

	@Autowired
	protected ImageHelper imageHelper;
	
	@Autowired
	protected ConfigurationWrapper configurationWrapper; 

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return null;
	}

	protected String resolveMessage(String message, Object... params) {
		return resolveMessage(message, locale, params);
	}

	protected String resolveMessage(String message, Locale locale, Object... params) {
		try {
			return messageSource.getMessage(message, params, locale);
		} catch (NoSuchMessageException e) {
			logger.warning(e.getMessage());
		}
		return message;
	}

	protected List<Error> resolveMessages(List<Error> messages, Locale locale) {
		if (messages == null || messages.isEmpty()) {
			return new ArrayList<Error>();
		}

		for (Error message : messages) {
			message.setMessage(resolveMessage(message.getCode(), locale));

		}
		return messages;
	}

	protected List<Error> resolveMessages(List<Error> messages) {
		return resolveMessages(messages, locale);
	}

	/**
	 * Error has itself error params but in case we won't use
	 * itself params we can use this method with  outer params
	 */
	protected Error resolveMessage(Error error, Object... params) {
		error.setMessage(resolveMessage(error.getCode(), params));
		return error;
	}
	
	protected Error resolveError(Error error) {
		error.setMessage(resolveMessage(error.getCode(), error.getParams()));
		return error;
	}

	@ExceptionHandler(NotLoggedException.class)
	public ModelAndView handleIOException(NotLoggedException ex) {
	ModelAndView model = new ModelAndView("login");
	model.addObject("message", resolveMessage("user.login.notLogged"));
	logger.warning(ex.getMessage());
	ex.printStackTrace();
	return model;
	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleIOException(Exception ex) {
	ModelAndView model = new ModelAndView("Error");
	logger.severe(ex.getMessage());
	ex.printStackTrace();
	return model;
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ModelAndView handleRuntimeException(RuntimeException ex) {
	ModelAndView model = new ModelAndView("Error");
	logger.severe(ex.getMessage());
	ex.printStackTrace();
	return model;
	}
	
	public String getCurrentUserEmail(HttpServletRequest request) throws NotLoggedException
	{
		Object email =  request.getSession().getAttribute(Constants.SESSION_EMAIL);
		if(email instanceof String)
		{
			return (String) email;
		}
		throw new NotLoggedException();
	
	}
	
	public Integer getCurrentUserId(HttpServletRequest request)throws NotLoggedException
	{
		Object userId =  request.getSession().getAttribute(Constants.SESSION_USER_ID);
		if(userId instanceof Integer)
		{
			return  (Integer) userId;
		}
		throw new NotLoggedException();
	}
}
