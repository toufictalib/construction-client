package com.sab2i.general;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.springframework.web.servlet.DispatcherServlet;

//com.sab2i.general.App
public class App extends DispatcherServlet {

	
/**
	 * 
	 */
	private static final long serialVersionUID = 2538966784134468839L;

@Override
public void init(ServletConfig config) throws ServletException {
	super.init(config);
}
}
