package com.sab2i.general;

public class NotFoundItem extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5225431403996572920L;

	public NotFoundItem() {
		super();
	}

	public NotFoundItem(String message) {
		super(message);
	}

	
}
