package com.sab2i.general;

import com.sab2i.controller.bean.request.AbstractDataSourceRequest;

public class ViewCriteriaRequest extends AbstractDataSourceRequest {
//	"{"catId":"1","viewOrder":"1","startDate":"","endDate":""}"
	private int catId;
	private int viewOrder;
	private String startDate;
	private String endDate;
	
	
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	public int getViewOrder() {
		return viewOrder;
	}
	public void setViewOrder(int viewOrder) {
		this.viewOrder = viewOrder;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
}
