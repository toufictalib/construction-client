package com.sab2i.general;

public class Success extends Response {

	public Success(Object data) {
		this();
		this.data = data;
	}

	public Success() {
		this.success = true;
	}
}
