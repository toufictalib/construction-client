package com.sab2i.general;

public class Constants {

	public final static int LATEST_PRODUCTS_COUNT = 10;

	public final static int IMAGE_MAIN = 1;
	public final static int IMAGE_OTHER = 0;

	public final static int MAX_ALLOWED_IMAGES = 4;

	public final static String PREFIX_IMAGE_MAIN = "main";
	public final static String PERFIX_IMAGE_OTHER = "other";

	public final static String REQUEST_USER_TITLE = "title";

	public static final String SESSION_USER_ID = "User_ID";
	public static final String SESSION_EMAIL = "email";
	
	public static final String SESSION_ADMIN = "isAdmin";
	
	public static final String SESSION_USER_NAME = "user_name";
	
	public static final String REQUEST_USER_ADMIN = "isAdmin";

	public static final String EMAIL_SENDER = "Could not connect to SMTP host: localhost, port: 25;";
}
