SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11)  AUTO_INCREMENT PRIMARY KEY,
  `date_creation` datetime NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11)  AUTO_INCREMENT PRIMARY KEY,
  `admin` bit(1) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `conf_details`
--

CREATE TABLE `conf_details` (
  `key_value` varchar(255) PRIMARY KEY,
  `key_label` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------



--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11)  AUTO_INCREMENT PRIMARY KEY,
  `date_creation` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `initialStock` int(11) DEFAULT NULL,
  `maxQuantityPerUser` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `numpo` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `reserved` int(11) DEFAULT NULL,
  `sellingTime` int(11) DEFAULT NULL,
  `sold` int(11) DEFAULT NULL,
  `category` int(11) NOT NULL,
  `client` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `id` int(11)  AUTO_INCREMENT PRIMARY KEY,
  `image_bytes`  LONGBLOB,
  `main_image` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `product` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` bigint(20)  AUTO_INCREMENT PRIMARY KEY,
  `purchase_date` datetime DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD KEY `FK_PRODUCT_CATEGORY` (`category`),
  ADD KEY `FK_PRODUCT_CLIENT` (`client`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD KEY `FK_PURCHASE_CLIENT` (`client`),
  ADD KEY `FK_PURCHASE_PRODUCT` (`product`);

--
-- Indexes for table `product_image`
--
  ALTER TABLE `product_image`
	ADD KEY `FK_IMAGE_MAIN_PRODUCT` (`product`),
	ADD KEY `FK_IMAGE_OTHERS_PRODUCT` (`product`),
	ADD INDEX( `main_image`);
--
-- Constraints for dumped tables
--


  -- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_PRODUCT_CATEGORY` FOREIGN KEY (`category`) REFERENCES `category` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_PRODUCT_CLIENT` FOREIGN KEY (`client`) REFERENCES `client` (`id`);

--
-- Constraints for table `product_image`
--
ALTER TABLE `product_image`
  ADD CONSTRAINT `FK_IMAGE_MAIN_PRODUCT` FOREIGN KEY (`main_image`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_IMAGE_OTHERS_PRODUCT` FOREIGN KEY (`product`) REFERENCES `product` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `FK_PURCHASE_CLIENT` FOREIGN KEY (`client`) REFERENCES `client` (`id`),
  ADD CONSTRAINT `FK_PURCHASE_PRODUCT` FOREIGN KEY (`product`) REFERENCES `product` (`id`) ON DELETE CASCADE;
  
  
  --
-- Dumping data for table `conf_details`
--

INSERT INTO `conf_details` (`key_Value`, `key_label`, `value`, `value_type`) VALUES
('RESERVATION_TIME', 'Reservation Time', '24', 'java.lang.Integer'),
('SELLING_TIME', 'Selling Time', '24', 'java.lang.Integer'),
('SEND_EMAIL', 'Send Email', 'true', 'java.lang.Boolean');