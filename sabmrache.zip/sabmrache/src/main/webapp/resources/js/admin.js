/**
 * 
 */





function res(for1) {

	var xyw = for1.qtt;
	var wyx = for1.qq;
	var name = for1.titre.value;

	if (xyw.value - wyx.value < 0 || wyx.value <= 0) {
		alert("Impossible de reserver cette quantit�");
	} else if (xyw.value - wyx.value >= 0 && for1.status.value == "EN STOCK") {

		var num1 = for1.qtt.value;
		var num2 = for1.qq.value;
		xyw.value = num1 - num2;
		alert("Produit " + name + " reserv�");
		if (xyw.value == 0) {
			for1.status.value = "RESERVE";
			for1.status.style.color = "orange";
			for1.qtt.style.color = "red";
			for1.buttonres.disabled = true;
			for1.buttonres.style.background = "#f1f1f1";
			for1.qtt.value = "0";
		}
	} else {
		for1.status.value = "RESERVE";
		for1.status.style.color = "orange";
		for1.qtt.style.color = "red";
		for1.buttonres.disabled = true;
		for1.qtt.value = "0";
	}
}

function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if (ele.style.display == "block") {
		ele.style.display = "none";
		text.innerHTML = " &nbsp Recherche avanc�e &nbsp   &darr;";
	} else {
		ele.style.display = "block";
		text.innerHTML = " &nbsp Recherche avanc�e &nbsp   &uarr;";
	}
}

function hide() {
	var date = document.getElementById('datetd');
	date.style.visibility = 'hidden';
}

function show() {
	var date = document.getElementById('datetd');
	date.style.visibility = 'visible';
}
function dateSelectHandler(select) {
	if (select.value == '1') {
		show();
	} else {
		hide();
	}
}


