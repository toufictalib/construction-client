/**
 * 
 */

function setCatId(selected, catId) {
	onCategoryClicking(catId, 5);

	$(".right-menu [selected]").each(function(index, obj) {

		$(obj).removeAttr('selected');
		$(obj).removeClass("selected");
	});

	$(selected).attr("selected", "selected");
	$(selected).addClass("selected");

}

function onCategoryClicking(catId, pageSize) {

	$(document).ready(function() {
		/*
		 * var MyDiv1 = document.getElementById('myProducts');
		 * MyDiv1.style.='visible';
		 */
		$("#myProducts").show();

		var dataObject =
		{
				catId:catId
			};
		
		
		var request =
		{
			url:"productsByCategory",
			type:"POST",
			data:dataObject,
			requestEnd:function(total)
			{
				setTopMenuValues(total);
			},
			
		}
		
		var dataSource = getDataSource(request);

		drawList(dataSource, "listView");

	});

}


function setTopMenuValues(listSize) {
	// set top menu
	$('#count').html("<b>" + listSize + "</b> produits");
}

function display(data) {
}



/**
 * it is using to handle requeset and fill empty
 * or no exists property with default value
 * @param request
 */
function handleRequest(request) {

	if (!request.contentType) {
		request.contentType = "application/json;charset=utf-8";
	}

	if (!request.dataType) {
		request.dataType = "json";
	}

	if (!request.pageSize) {
		request.pageSize = 5;
	}

	if (!request.serverPaging) {
		request.serverPaging = true;
	}
}


function getDataSource(request)
{
	handleRequest(request);
	var dataSource = new kendo.data.DataSource({
		transport : {
			read : {
				url : request.url,
				contentType : request.contentType,
				type: request.type,
				dataType : request.dataType,
				data:request.data,

			},
			parameterMap : function(options, operation) {
				return JSON.stringify(options);
			}
			
		},

		requestEnd : function(e) {
			if (e.type === "read" && e.response) {
				var response = e.response;
				request.requestEnd(response.total);

			}
		},
		schema: {
			data:"data",
			total:"total"
		  },

		pageSize : request.pageSize,
		serverPaging: request.serverPaging
	});
	
	return dataSource;
}

function drawList(dataSource, listId) {
	var listView = $("#" + listId).data("kendoListView");
	
	if(listView)
		{
			listView.destroy();
		}
	
	var pager = $("#pager").data("kendoPager");
	if(pager)
		{
		 pager.destroy();
		}
	
	$("#pager").kendoPager({
		dataSource : dataSource
	});

	$("#" + listId).kendoListView({
		dataSource : dataSource,
		template : kendo.template($("#template").html()),
		dataBound : function() {
			var grid = this;
			var model = grid.dataItem(this);


			

		},
		 pageable: true
	});

}

function reserveProduct(for1, userId, productId, reservedQuantity, maxQuantity) {

	var reservation = {
		"userId" : userId,
		"productId" : productId,
		"quantity" : reservedQuantity

	};
	callAjax("reserveProduct", reservation, function(data) {
		if (data.success) {
			showDialog("success",data.data.message);

			// update reserved and sold labels
			var reserved = data.data.reserved;
			$("#reserved_" + productId).text(reserved);
			$("#vendu_" + productId).text(data.data.vendu);

			$("#listView").data("kendoListView").dataSource.read();
			$("#listView").data("kendoListView").refresh();

			// update values
			if (maxQuantity - reservedQuantity >= 0
					&& for1.status.value == "EN STOCK") {

				var num1 = for1.qtt.value;
				var num2 = for1.qq.value;
				maxQuantity = num1 - num2;

				/*
				 * if (maxQuantity == 0) { for1.status.value = "RESERVE";
				 * for1.status.style.color = "orange"; for1.qtt.style.color =
				 * "red"; for1.buttonres.disabled = true;
				 * for1.buttonres.style.background = "#f1f1f1"; for1.qtt.value =
				 * "0"; } else { for1.status.value = "RESERVE";
				 * for1.status.style.color = "orange"; for1.qtt.style.color =
				 * "red"; for1.buttonres.disabled = true; for1.qtt.value =
				 * maxQuantity; }
				 */
			}

		} else {
			showMessage(data.errors[0].message);
		}
	});
}

function res(for1, maxValue, productId) {

	var availableStock = for1.qtt.value;
	var reservedQuantity = for1.qq.value;

	var reservationDetails = new ReservationDetails(maxValue, availableStock,
			reservedQuantity);

	var validationSuccess = validateReservationInput(reservationDetails);

	if (validationSuccess) {
		reserveProduct(for1, 1, productId, reservedQuantity, availableStock);
	}
}

function validateReservationInput(reservationDetails) {
	var passing = false;
	var availableStock = reservationDetails.availableStock;
	var reservedQuantity = reservationDetails.reservedQuantity;
	var maxPerUser = reservationDetails.maxPerUser;
	// var name = for1.titre.value;

	if (!reservedQuantity) {
		showMessage("Vous devez remplir le champ quantité");
	} else if (reservedQuantity < 0) {
		showMessage("Vous devez remplir le champ quantité avec positive numero");
	} else if (availableStock - reservedQuantity < 0 || reservedQuantity <= 0) {
		showMessage("Impossible de reserver une quantité superieure a celle disponible");
	} else if (reservedQuantity > maxPerUser) {
		showMessage("Vous ne pouvez pas reserver plus de " + maxPerUser);
	} else {
		passing = true;
	}

	return passing;
}

function reserveFromDetailsPage(for1) {
	var productId = for1.IP.value;
	var reservedQuantity = for1.foo.value;
	var availableStock = for1.qtd.value;
	var maxValuePerUser = for1.qt.value;
	var userId = 1;

	var reservationDetails = new ReservationDetails(maxValuePerUser,
			availableStock, reservedQuantity);

	var validationSuccess = validateReservationInput(reservationDetails);

	if (validationSuccess) {
		var reservation = {
			"userId" : userId,
			"productId" : productId,
			"quantity" : reservedQuantity

		};
		callAjax("reserveProduct", reservation, function(data) {
			if (data.success) {
				showDialog("Success",data.data.message);

				// update reserved and sold labels
				var reserved = data.data.reserved;
				$("#reserved").text(reserved);
				$("#vendu").text(data.data.vendu);

				// update values
				if (maxQuantity - reservedQuantity >= 0
						&& for1.status.value == "EN STOCK") {

					var num1 = for1.qtt.value;
					var num2 = for1.qq.value;
					maxQuantity = maxValuePerUser - reservedQuantity;

					if (maxQuantity == 0) {
						for1.status.value = "RESERVE";
						for1.status.style.color = "orange";
						for1.qtt.style.color = "red";
						for1.buttonres.disabled = true;
						for1.buttonres.style.background = "#f1f1f1";
						for1.qtt.value = "0";
					} else {
						for1.status.value = "RESERVE";
						for1.status.style.color = "orange";
						for1.qtt.style.color = "red";
						for1.buttonres.disabled = true;
						for1.qtt.value = maxQuantity;
					}
				}

			} else {
				showDialog("Warning",data.errors[0].message);
			}
		});
	}

}

function showMessage(message) {
	showDialog("Error", message);
}

function showMessages(messages) {
	var html = "";
	for (i=0;i<messages.length;i++) {
		error = messages[i];
		html+= error.message + "</br>";
	}
	showMessage(html);
}


function showDialog(title,message)
{
	var iDiv = document.createElement('div');
	iDiv.id = 'dialog-message';
	iDiv.setAttribute("title", title);
	$("body").append(iDiv);
	$("#dialog-message")
	.html(message)
	.dialog({
		modal: true,
		buttons: {
			Ok: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function( event, ui ) {
			$(this).dialog('destroy').remove();
		}
	});
}

function confirmationDialogs(title,message,doFunctionForYes,doFunctionForNo)
{
	var iDiv = document.createElement('div');
	iDiv.id = 'dialog-message';
	iDiv.setAttribute("title", title);
	$(iDiv).appendTo('body')
	  .html('<div><h6>'+message+'</h6></div>')
	  .dialog({
	      modal: true, title: title, zIndex: 10000, autoOpen: true,
	      width: 'auto', resizable: false,
	      buttons: {
	          Oui: function () {
	        	  doFunctionForYes();
	              $(this).dialog("close");
	          },
	          Non: function () {
	              doFunctionForNo();
	              $(this).dialog("close");
	          }
	      },
	      close: function (event, ui) {
	          $(this).remove();
	      }
	});
}

function confirmationDialog(messageConf) {
	if (!messageConf.title) {
		messageConf.title = "Oui/Non";
	}

	if (!messageConf.doFunctionForNo) {
		messageConf.doFunctionForNo = function() {

		};
	}
	confirmationDialogs(messageConf.title, messageConf.message,
			messageConf.doFunctionForYe, messageConf.doFunctionForNo);

}


/**
 * 
 * @param url
 * @param object
 *            javascript object before converting to JSON
 * @param successHandler
 * @param errorHandler
 */
function callAjax(url, object, successHandler, errorHandler) {
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : url,
		data : JSON.stringify(object),
		dataType : 'json',
		timeout : 100000,
		success : function(data) {
			console.log("SUCCESS: ", data);
			successHandler(data);

		},
		error : function(e) {
			console.log("ERROR: ", e);
			errorHandler(e);
		},
	});
}

/**
 * 
 * @param url
 * @param object
 * @param successHandler
 */
function callAjax(url, object, successHandler) {
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : url,
		data : JSON.stringify(object),
		dataType : 'json',
		timeout : 100000,
		success : function(data) {
			console.log("SUCCESS: ", data);
			successHandler(data);

		},
		error : function(e) {
			console.log("ERROR: ", e);
			showMessage("Unknow Error,please call the supports")
		},
	});
}

function dateSelectHandler(select) {
	if (select.value == '1') {
		show();
	} else {
		hide();
	}
}
function hide() {
	var date = document.getElementById('datetd');
	date.style.visibility = 'hidden';
}

function show() {
	var date = document.getElementById('datetd');
	date.style.visibility = 'visible';
}

function trierListe() {

	// jsonValue

	var catId = $(".right-menu [selected]").attr("id");

	var a = [ "catId", "viewOrder", "startDate", "endDate" ];

	var values = [ catId ];

	var map = {
		catId : catId,
		viewOrder: $("#viewOrder").val(),
		startDate : $("#startDate").val(),
		endDate : $("#endDate").val()

	}



	var request =
	{
		url:"organizedProductsByCategory",
		type:"POST",
		data:map,
		requestEnd:function(total)
		{
			setTopMenuValues(total);
		},
		
	}
	
	var dataSource = getDataSource(request);

	drawList(dataSource, "listView");
}

function ReservationDetails(maxPerUser, availableStock, reservedQuantity) {
	this.maxPerUser = parseInt(maxPerUser);
	this.availableStock = parseInt(availableStock);
	this.reservedQuantity = parseInt(reservedQuantity);
}

function getGategoryManager(event) {
	fillMainDiv(event, "jsp/category.jsp");
}

function getOrders(event) {
	fillMainDiv(event, "jsp/order.jsp");
}

function getConfigurationPanel(event) {
	fillMainDiv(event, "jsp/configurationPanel.jsp");
}

function getDashboard(event) {
	fillMainDiv(event, "jsp/dashboard.jsp");
}

function fillMainDiv(event, jspUrl) {
	clearMainDiv();
	$("#side-menu li").removeClass("selected");
	$(event).parent().addClass("selected");
	$("#myWrapper").load(jspUrl);

}
function clearMainDiv() {
	$("#myWrapper").empty();
}

function getProductsByCategory(event, categoryId) {

	fillMainDiv(event, "jsp/product.jsp");
	console.log("Waiting");
}

function deleteImage(element, file, mainImage) {

	var object = {
		"productId" : $("#productId").val(),
		"mainImage" : mainImage,
		"fileName" : file
	};
	callAjax("product/remove", object, function(data) {
		if (data.success) {
			$(element).parent().remove();

			/*
			 * $(element).parent().find("img").remove();
			 * $(element).parent().find(element).remove();
			 */
		}

	});

}

function loadImages(url, template) {
	console.log("loading images");
	callAjax(url, "", function(data) {
		if (data.success) {

			console.log("success");
			if (data.data.mainImage) {
				$("#product-main-image").html(kendo.render(template, [ {
					"name" : data.data.mainImage.name,"mainImage":1,
					"byteArray":data.data.mainImage.byteArray
				} ]));
			}
			console.log("main");
			var otherImages = [];
			for (i = 0; i < data.data.otherImages.length; i++) {

				otherImages[i] = {
					"name" : data.data.otherImages[i].name,"mainImage":0,
					"byteArray":data.data.otherImages[i].byteArray
				};
			}
			console.log("other");
			$("#products").html(kendo.render(template, otherImages));
			console.log("draw");
		}

	});
	
	
	
}

